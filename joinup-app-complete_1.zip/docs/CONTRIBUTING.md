# Contributing to JoinUp

Thank you for your interest in contributing to JoinUp! This document provides guidelines and information for contributors.

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Workflow](#development-workflow)
- [Coding Standards](#coding-standards)
- [Commit Guidelines](#commit-guidelines)
- [Pull Request Process](#pull-request-process)
- [Reporting Bugs](#reporting-bugs)
- [Suggesting Features](#suggesting-features)

## Code of Conduct

Please be respectful and inclusive. We're all here to build something great together.

## Getting Started

### Prerequisites

- Node.js 20+
- pnpm 8+
- Docker & Docker Compose
- Git

### Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/joinup-app.git
cd joinup-app

# Run setup script
chmod +x scripts/setup.sh
./scripts/setup.sh

# Or manually:
pnpm install
cp .env.example .env.local
docker-compose up -d
pnpm db:migrate
pnpm db:seed
```

### Running Locally

```bash
# Start all services
pnpm dev

# Or run individually:
pnpm --filter api dev      # Backend only
pnpm --filter mobile dev   # Mobile app only
```

## Development Workflow

### Branching Strategy

- `main` - Production-ready code
- `develop` - Development branch (PR target)
- `feature/*` - New features
- `fix/*` - Bug fixes
- `docs/*` - Documentation updates
- `refactor/*` - Code refactoring

### Creating a Feature Branch

```bash
# From develop branch
git checkout develop
git pull origin develop
git checkout -b feature/my-feature
```

### Making Changes

1. Write your code
2. Add tests if applicable
3. Run linting: `pnpm lint`
4. Run tests: `pnpm test`
5. Commit your changes

## Coding Standards

### TypeScript

- Use strict TypeScript settings
- Prefer interfaces over types for objects
- Use explicit return types for functions
- Avoid `any` - use `unknown` if needed

```typescript
// Good
interface User {
  id: string;
  name: string;
}

function getUser(id: string): Promise<User | null> {
  // ...
}

// Avoid
const getUser = (id: any) => {
  // ...
};
```

### React/React Native

- Use functional components with hooks
- Use TypeScript for all components
- Keep components small and focused
- Use meaningful component names

```tsx
// Good
interface ButtonProps {
  onPress: () => void;
  label: string;
  variant?: 'primary' | 'secondary';
}

export function Button({ onPress, label, variant = 'primary' }: ButtonProps) {
  return (
    <TouchableOpacity onPress={onPress} style={styles[variant]}>
      <Text>{label}</Text>
    </TouchableOpacity>
  );
}
```

### File Organization

```
feature/
├── components/
│   ├── FeatureCard.tsx
│   └── FeatureList.tsx
├── hooks/
│   └── useFeature.ts
├── utils/
│   └── featureHelpers.ts
└── index.ts
```

### Naming Conventions

- **Files**: `kebab-case.ts` or `PascalCase.tsx` for components
- **Variables/Functions**: `camelCase`
- **Constants**: `SCREAMING_SNAKE_CASE`
- **Types/Interfaces**: `PascalCase`
- **Components**: `PascalCase`

## Commit Guidelines

We follow [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

### Types

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Formatting (no code change)
- `refactor`: Code refactoring
- `test`: Adding tests
- `chore`: Maintenance

### Examples

```bash
feat(auth): add password reset functionality
fix(events): correct date formatting issue
docs(readme): update installation instructions
refactor(api): simplify error handling middleware
```

## Pull Request Process

1. **Create PR** against `develop` branch
2. **Fill out template** completely
3. **Wait for CI** to pass
4. **Request review** from maintainers
5. **Address feedback** if any
6. **Merge** when approved

### PR Checklist

- [ ] Code follows style guidelines
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] No console.log statements
- [ ] No commented-out code
- [ ] PR description is clear

## Reporting Bugs

Use the bug report template and include:

1. **Description** - Clear explanation
2. **Steps to reproduce** - Numbered steps
3. **Expected behavior** - What should happen
4. **Actual behavior** - What happens
5. **Environment** - OS, app version, device
6. **Screenshots** - If applicable

## Suggesting Features

Use the feature request template and include:

1. **Problem** - What problem does this solve?
2. **Solution** - Your proposed solution
3. **Alternatives** - Other approaches considered
4. **User story** - As a [user], I want [feature]

## Questions?

Feel free to open a discussion or reach out to the maintainers.

---

Thank you for contributing! 🎉

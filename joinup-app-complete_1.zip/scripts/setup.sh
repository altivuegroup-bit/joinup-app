#!/bin/bash

# =============================================================================
# JoinUp - Initial Setup Script
# =============================================================================

set -e

echo "🚀 JoinUp Setup Script"
echo "======================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check prerequisites
echo "📋 Checking prerequisites..."

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js is not installed. Please install Node.js 20+${NC}"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
    echo -e "${YELLOW}⚠️  Node.js version is $NODE_VERSION. Recommended: 20+${NC}"
fi
echo -e "${GREEN}✅ Node.js $(node -v)${NC}"

# Check pnpm
if ! command -v pnpm &> /dev/null; then
    echo -e "${YELLOW}📦 Installing pnpm...${NC}"
    npm install -g pnpm
fi
echo -e "${GREEN}✅ pnpm $(pnpm -v)${NC}"

# Check Docker
if ! command -v docker &> /dev/null; then
    echo -e "${YELLOW}⚠️  Docker is not installed. You'll need it for local development.${NC}"
else
    echo -e "${GREEN}✅ Docker $(docker -v | cut -d' ' -f3 | cut -d',' -f1)${NC}"
fi

echo ""

# Install dependencies
echo "📦 Installing dependencies..."
pnpm install

echo ""

# Setup environment files
echo "🔧 Setting up environment files..."

if [ ! -f ".env.local" ]; then
    cp .env.example .env.local
    echo -e "${GREEN}✅ Created .env.local from .env.example${NC}"
    echo -e "${YELLOW}⚠️  Please edit .env.local with your actual values${NC}"
else
    echo -e "${GREEN}✅ .env.local already exists${NC}"
fi

echo ""

# Generate secrets
echo "🔐 Generating secure secrets..."

JWT_ACCESS_SECRET=$(openssl rand -base64 64 | tr -d '\n')
JWT_REFRESH_SECRET=$(openssl rand -base64 64 | tr -d '\n')
ENCRYPTION_KEY=$(openssl rand -hex 32)

echo ""
echo "Add these to your .env.local file:"
echo "-----------------------------------"
echo "JWT_ACCESS_SECRET=\"$JWT_ACCESS_SECRET\""
echo ""
echo "JWT_REFRESH_SECRET=\"$JWT_REFRESH_SECRET\""
echo ""
echo "ENCRYPTION_KEY=\"$ENCRYPTION_KEY\""
echo "-----------------------------------"
echo ""

# Start Docker services
if command -v docker &> /dev/null; then
    echo "🐳 Starting Docker services (PostgreSQL, Redis)..."
    docker-compose up -d
    
    echo "⏳ Waiting for services to be ready..."
    sleep 5
else
    echo -e "${YELLOW}⚠️  Skipping Docker services (Docker not installed)${NC}"
fi

# Generate Prisma client
echo "🗄️  Generating Prisma client..."
pnpm db:generate

# Run database migrations
echo "🗄️  Running database migrations..."
pnpm db:migrate

# Seed database
echo "🌱 Seeding database with sample data..."
pnpm db:seed

echo ""
echo "============================================"
echo -e "${GREEN}✅ Setup complete!${NC}"
echo "============================================"
echo ""
echo "Next steps:"
echo "1. Edit .env.local with your actual values"
echo "2. Run: pnpm dev"
echo "3. API will be available at: http://localhost:3001"
echo ""
echo "Test account:"
echo "  Email: demo@joinup.app"
echo "  Password: Password123!"
echo ""

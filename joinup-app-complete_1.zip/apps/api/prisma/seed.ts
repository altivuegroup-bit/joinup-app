// =============================================================================
// DATABASE SEED
// =============================================================================

import { PrismaClient, EventCategory, EventStatus, SubscriptionTier } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

const SALT_ROUNDS = 12;

async function main() {
  console.log('🌱 Starting database seed...');

  // ==========================================================================
  // USERS
  // ==========================================================================

  const passwordHash = await bcrypt.hash('Password123!', SALT_ROUNDS);

  const users = await Promise.all([
    prisma.user.upsert({
      where: { email: 'demo@joinup.app' },
      update: {},
      create: {
        email: 'demo@joinup.app',
        passwordHash,
        name: 'Demo User',
        username: 'demouser',
        bio: 'Exploring events and meeting new people! 🎉',
        avatarUrl: 'https://i.pravatar.cc/150?img=33',
        subscriptionTier: 'CONNECT',
        emailVerified: true,
      },
    }),
    prisma.user.upsert({
      where: { email: 'sarah@joinup.app' },
      update: {},
      create: {
        email: 'sarah@joinup.app',
        passwordHash,
        name: 'Sarah Chen',
        username: 'sarahchen',
        bio: 'Yoga instructor & wellness advocate 🧘‍♀️',
        avatarUrl: 'https://i.pravatar.cc/150?img=1',
        subscriptionTier: 'CREATOR',
        emailVerified: true,
      },
    }),
    prisma.user.upsert({
      where: { email: 'marcus@joinup.app' },
      update: {},
      create: {
        email: 'marcus@joinup.app',
        passwordHash,
        name: 'Marcus Rivera',
        username: 'marcusmusic',
        bio: 'Music curator & event host 🎵',
        avatarUrl: 'https://i.pravatar.cc/150?img=3',
        subscriptionTier: 'CREATOR',
        emailVerified: true,
      },
    }),
    prisma.user.upsert({
      where: { email: 'alex@joinup.app' },
      update: {},
      create: {
        email: 'alex@joinup.app',
        passwordHash,
        name: 'Alex Kim',
        username: 'alexcodes',
        bio: 'Developer & tech enthusiast 💻',
        avatarUrl: 'https://i.pravatar.cc/150?img=5',
        subscriptionTier: 'CONNECT',
        emailVerified: true,
      },
    }),
    prisma.user.upsert({
      where: { email: 'emma@joinup.app' },
      update: {},
      create: {
        email: 'emma@joinup.app',
        passwordHash,
        name: 'Emma Watson',
        username: 'emmafood',
        bio: 'Food blogger & culinary explorer 🍜',
        avatarUrl: 'https://i.pravatar.cc/150?img=9',
        subscriptionTier: 'CREATOR',
        emailVerified: true,
      },
    }),
  ]);

  console.log(`✅ Created ${users.length} users`);

  // ==========================================================================
  // SOCIAL CONNECTIONS
  // ==========================================================================

  await prisma.socialConnection.createMany({
    skipDuplicates: true,
    data: [
      { userId: users[1].id, platform: 'INSTAGRAM', platformUserId: '1', platformUsername: 'sarahchen_yoga' },
      { userId: users[1].id, platform: 'TIKTOK', platformUserId: '1', platformUsername: 'sarahchen_yoga' },
      { userId: users[2].id, platform: 'INSTAGRAM', platformUserId: '2', platformUsername: 'marcus_beats' },
      { userId: users[2].id, platform: 'TWITTER', platformUserId: '2', platformUsername: 'marcusrivera' },
      { userId: users[3].id, platform: 'LINKEDIN', platformUserId: '3', platformUsername: 'alexkim' },
      { userId: users[3].id, platform: 'TWITTER', platformUserId: '3', platformUsername: 'alexcodes' },
    ],
  });

  console.log('✅ Created social connections');

  // ==========================================================================
  // EVENTS
  // ==========================================================================

  const now = new Date();
  const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  const nextMonth = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

  const events = await Promise.all([
    prisma.event.upsert({
      where: { slug: 'sunset-yoga-park' },
      update: {},
      create: {
        hostId: users[1].id,
        title: 'Sunset Yoga in the Park',
        slug: 'sunset-yoga-park',
        description: 'Join us for a relaxing sunset yoga session in Central Park. All levels welcome! Bring your own mat or rent one from us. We\'ll flow through gentle poses as the sun sets over the city.',
        imageUrl: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=800',
        category: 'WELLNESS',
        tags: ['yoga', 'wellness', 'outdoor', 'beginner-friendly'],
        locationName: 'Central Park - Sheep Meadow',
        locationAddress: 'Central Park West, New York, NY 10024',
        locationLat: 40.7712,
        locationLng: -73.9742,
        startTime: new Date(tomorrow.setHours(18, 0, 0)),
        endTime: new Date(tomorrow.setHours(19, 30, 0)),
        capacity: 50,
        status: 'PUBLISHED',
        publishedAt: now,
        attendeeCount: 23,
        avgRating: 4.8,
        reviewCount: 12,
      },
    }),
    prisma.event.upsert({
      where: { slug: 'indie-music-night' },
      update: {},
      create: {
        hostId: users[2].id,
        title: 'Indie Music Night',
        slug: 'indie-music-night',
        description: 'An evening of amazing indie music featuring local artists. Get ready for an unforgettable night of live performances, good vibes, and great music.',
        imageUrl: 'https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?w=800',
        category: 'MUSIC',
        tags: ['music', 'indie', 'live', 'nightlife'],
        locationName: 'The Blue Note',
        locationAddress: '131 W 3rd St, New York, NY 10012',
        locationLat: 40.7308,
        locationLng: -74.0005,
        startTime: new Date(nextWeek.setHours(20, 0, 0)),
        endTime: new Date(nextWeek.setHours(23, 30, 0)),
        capacity: 150,
        status: 'PUBLISHED',
        publishedAt: now,
        attendeeCount: 89,
        avgRating: 4.6,
        reviewCount: 34,
      },
    }),
    prisma.event.upsert({
      where: { slug: 'coffee-code-meetup' },
      update: {},
      create: {
        hostId: users[3].id,
        title: 'Coffee & Code Meetup',
        slug: 'coffee-code-meetup',
        description: 'Casual coding meetup for developers of all levels. Bring your laptop, work on projects, learn from others, and enjoy great coffee!',
        imageUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800',
        category: 'TECH',
        tags: ['coding', 'tech', 'networking', 'coffee'],
        locationName: 'TechHub Cafe',
        locationAddress: '350 5th Ave, New York, NY 10118',
        locationLat: 40.7484,
        locationLng: -73.9857,
        startTime: new Date(tomorrow.setHours(10, 0, 0)),
        endTime: new Date(tomorrow.setHours(13, 0, 0)),
        capacity: 30,
        status: 'PUBLISHED',
        publishedAt: now,
        attendeeCount: 18,
        avgRating: 4.9,
        reviewCount: 8,
      },
    }),
    prisma.event.upsert({
      where: { slug: 'street-food-festival' },
      update: {},
      create: {
        hostId: users[4].id,
        title: 'Street Food Festival',
        slug: 'street-food-festival',
        description: 'Taste cuisines from around the world at our annual street food festival! Over 30 vendors serving delicious food from different cultures.',
        imageUrl: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800',
        category: 'FOOD',
        tags: ['food', 'festival', 'outdoor', 'family-friendly'],
        locationName: 'Downtown Square',
        locationAddress: 'Times Square, New York, NY 10036',
        locationLat: 40.758,
        locationLng: -73.9855,
        startTime: new Date(nextMonth.setHours(12, 0, 0)),
        endTime: new Date(nextMonth.setHours(20, 0, 0)),
        capacity: 500,
        status: 'PUBLISHED',
        publishedAt: now,
        attendeeCount: 234,
        avgRating: 4.7,
        reviewCount: 56,
      },
    }),
    prisma.event.upsert({
      where: { slug: 'virtual-book-club' },
      update: {},
      create: {
        hostId: users[0].id,
        title: 'Virtual Book Club - Sci-Fi Edition',
        slug: 'virtual-book-club',
        description: 'Join our online book club discussion! This month we\'re reading "Project Hail Mary" by Andy Weir. New members welcome!',
        imageUrl: 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=800',
        category: 'SOCIAL',
        tags: ['books', 'reading', 'virtual', 'sci-fi'],
        isOnline: true,
        onlineUrl: 'https://zoom.us/j/example',
        startTime: new Date(nextWeek.setHours(19, 0, 0)),
        endTime: new Date(nextWeek.setHours(20, 30, 0)),
        capacity: 30,
        status: 'PUBLISHED',
        publishedAt: now,
        attendeeCount: 15,
        avgRating: 4.5,
        reviewCount: 6,
      },
    }),
  ]);

  console.log(`✅ Created ${events.length} events`);

  // ==========================================================================
  // TICKET TYPES
  // ==========================================================================

  await prisma.ticketType.createMany({
    skipDuplicates: true,
    data: [
      // Yoga event - free
      { eventId: events[0].id, name: 'General Admission', priceCents: 0, quantity: 50, isActive: true },
      // Music night
      { eventId: events[1].id, name: 'General Admission', priceCents: 1500, quantity: 100, isActive: true },
      { eventId: events[1].id, name: 'VIP', priceCents: 3500, quantity: 20, description: 'Front row + meet & greet', isActive: true },
      // Code meetup - free
      { eventId: events[2].id, name: 'Free Entry', priceCents: 0, quantity: 30, isActive: true },
      // Food festival
      { eventId: events[3].id, name: 'Day Pass', priceCents: 500, quantity: 400, isActive: true },
      { eventId: events[3].id, name: 'VIP Tasting Pass', priceCents: 2500, quantity: 50, description: 'Unlimited tastings at all vendors', isActive: true },
      // Book club - free
      { eventId: events[4].id, name: 'Free Entry', priceCents: 0, quantity: 30, isActive: true },
    ],
  });

  console.log('✅ Created ticket types');

  // ==========================================================================
  // FOLLOWS
  // ==========================================================================

  await prisma.follow.createMany({
    skipDuplicates: true,
    data: [
      { followerId: users[0].id, followingId: users[1].id },
      { followerId: users[0].id, followingId: users[2].id },
      { followerId: users[0].id, followingId: users[4].id },
      { followerId: users[1].id, followingId: users[0].id },
      { followerId: users[2].id, followingId: users[1].id },
      { followerId: users[3].id, followingId: users[0].id },
      { followerId: users[3].id, followingId: users[1].id },
      { followerId: users[3].id, followingId: users[2].id },
    ],
  });

  console.log('✅ Created follow relationships');

  // ==========================================================================
  // EVENT ATTENDEES
  // ==========================================================================

  await prisma.eventAttendee.createMany({
    skipDuplicates: true,
    data: [
      { eventId: events[0].id, userId: users[0].id, status: 'GOING' },
      { eventId: events[0].id, userId: users[3].id, status: 'GOING' },
      { eventId: events[1].id, userId: users[0].id, status: 'GOING' },
      { eventId: events[1].id, userId: users[1].id, status: 'GOING' },
      { eventId: events[1].id, userId: users[3].id, status: 'MAYBE' },
      { eventId: events[2].id, userId: users[0].id, status: 'GOING' },
      { eventId: events[2].id, userId: users[1].id, status: 'GOING' },
      { eventId: events[3].id, userId: users[0].id, status: 'GOING' },
      { eventId: events[4].id, userId: users[3].id, status: 'GOING' },
    ],
  });

  console.log('✅ Created event attendees');

  // ==========================================================================
  // REVIEWS
  // ==========================================================================

  // Note: In production, only past events should have reviews
  await prisma.review.createMany({
    skipDuplicates: true,
    data: [
      {
        eventId: events[0].id,
        userId: users[3].id,
        rating: 5,
        title: 'Amazing experience!',
        content: 'Such a peaceful way to end the day. Sarah is an incredible instructor!',
      },
      {
        eventId: events[1].id,
        userId: users[0].id,
        rating: 5,
        title: 'Best live music I\'ve seen',
        content: 'The bands were incredible and the venue was perfect. Will definitely come again!',
      },
      {
        eventId: events[2].id,
        userId: users[1].id,
        rating: 5,
        title: 'Great community',
        content: 'Met so many cool developers and learned a lot. The coffee was great too!',
      },
    ],
  });

  console.log('✅ Created reviews');

  console.log('');
  console.log('🎉 Database seeded successfully!');
  console.log('');
  console.log('📝 Test Accounts:');
  console.log('   Email: demo@joinup.app');
  console.log('   Password: Password123!');
  console.log('');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

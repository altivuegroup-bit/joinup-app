// =============================================================================
// STRIPE PAYMENT SERVICE
// =============================================================================

import Stripe from 'stripe';
import { config } from '../config/env';
import { prisma } from '../utils/prisma';
import { logger } from '../utils/logger';
import { SubscriptionTier } from '@prisma/client';

// Initialize Stripe
const stripe = config.stripe.secretKey
  ? new Stripe(config.stripe.secretKey, { apiVersion: '2023-10-16' })
  : null;

// =============================================================================
// TYPES
// =============================================================================

interface CreateCheckoutParams {
  userId: string;
  ticketTypeId: string;
  quantity: number;
  successUrl: string;
  cancelUrl: string;
}

interface CreateSubscriptionParams {
  userId: string;
  planId: 'connect' | 'creator';
}

// =============================================================================
// SERVICE
// =============================================================================

export const stripeService = {
  /**
   * Create or get Stripe customer for user
   */
  getOrCreateCustomer: async (userId: string): Promise<string> => {
    if (!stripe) throw new Error('Stripe not configured');

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        stripeCustomerId: true,
      },
    });

    if (!user) throw new Error('User not found');

    // Return existing customer ID
    if (user.stripeCustomerId) {
      return user.stripeCustomerId;
    }

    // Create new Stripe customer
    const customer = await stripe.customers.create({
      email: user.email,
      name: user.name,
      metadata: {
        userId: user.id,
      },
    });

    // Save customer ID
    await prisma.user.update({
      where: { id: userId },
      data: { stripeCustomerId: customer.id },
    });

    logger.info(`Created Stripe customer for user ${userId}: ${customer.id}`);

    return customer.id;
  },

  /**
   * Create checkout session for event tickets
   */
  createCheckoutSession: async (params: CreateCheckoutParams): Promise<Stripe.Checkout.Session> => {
    if (!stripe) throw new Error('Stripe not configured');

    const { userId, ticketTypeId, quantity, successUrl, cancelUrl } = params;

    // Get ticket and event info
    const ticket = await prisma.ticketType.findUnique({
      where: { id: ticketTypeId },
      include: {
        event: {
          include: {
            host: {
              select: {
                id: true,
                stripeCustomerId: true,
              },
            },
          },
        },
      },
    });

    if (!ticket) throw new Error('Ticket type not found');
    if (!ticket.isActive) throw new Error('Ticket type is not available');
    if (ticket.quantity - ticket.quantitySold < quantity) {
      throw new Error('Not enough tickets available');
    }

    // Get or create customer
    const customerId = await stripeService.getOrCreateCustomer(userId);

    // Calculate platform fee (2% for paid tickets)
    const platformFeePercent = 0.02;
    const platformFee = Math.round(ticket.priceCents * quantity * platformFeePercent);

    // Create line items
    const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = [
      {
        price_data: {
          currency: 'usd',
          product_data: {
            name: `${ticket.event.title} - ${ticket.name}`,
            description: ticket.description || undefined,
          },
          unit_amount: ticket.priceCents,
        },
        quantity,
      },
    ];

    // Create session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: lineItems,
      mode: 'payment',
      success_url: successUrl,
      cancel_url: cancelUrl,
      metadata: {
        userId,
        ticketTypeId,
        eventId: ticket.event.id,
        quantity: quantity.toString(),
      },
      payment_intent_data: {
        metadata: {
          userId,
          ticketTypeId,
          eventId: ticket.event.id,
        },
        // Application fee for platform
        application_fee_amount: platformFee,
      },
    });

    logger.info(`Created checkout session: ${session.id}`);

    return session;
  },

  /**
   * Create subscription
   */
  createSubscription: async (params: CreateSubscriptionParams): Promise<Stripe.Subscription> => {
    if (!stripe) throw new Error('Stripe not configured');

    const { userId, planId } = params;

    // Get price ID
    const priceId = planId === 'connect'
      ? config.stripe.prices.connectMonthly
      : config.stripe.prices.creatorMonthly;

    if (!priceId) throw new Error(`Price not configured for plan: ${planId}`);

    // Get or create customer
    const customerId = await stripeService.getOrCreateCustomer(userId);

    // Check for existing subscription
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { stripeSubscriptionId: true },
    });

    if (user?.stripeSubscriptionId) {
      // Update existing subscription
      const subscription = await stripe.subscriptions.update(user.stripeSubscriptionId, {
        items: [{ price: priceId }],
        proration_behavior: 'always_invoice',
      });

      logger.info(`Updated subscription for user ${userId}`);
      return subscription;
    }

    // Create new subscription
    const subscription = await stripe.subscriptions.create({
      customer: customerId,
      items: [{ price: priceId }],
      payment_behavior: 'default_incomplete',
      payment_settings: {
        save_default_payment_method: 'on_subscription',
      },
      expand: ['latest_invoice.payment_intent'],
      metadata: {
        userId,
        planId,
      },
    });

    // Save subscription ID
    await prisma.user.update({
      where: { id: userId },
      data: { stripeSubscriptionId: subscription.id },
    });

    logger.info(`Created subscription for user ${userId}: ${subscription.id}`);

    return subscription;
  },

  /**
   * Cancel subscription
   */
  cancelSubscription: async (userId: string): Promise<void> => {
    if (!stripe) throw new Error('Stripe not configured');

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { stripeSubscriptionId: true },
    });

    if (!user?.stripeSubscriptionId) {
      throw new Error('No active subscription');
    }

    // Cancel at period end
    await stripe.subscriptions.update(user.stripeSubscriptionId, {
      cancel_at_period_end: true,
    });

    logger.info(`Cancelled subscription for user ${userId}`);
  },

  /**
   * Handle webhook events
   */
  handleWebhook: async (event: Stripe.Event): Promise<void> => {
    logger.info(`Processing webhook: ${event.type}`);

    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        await handleCheckoutComplete(session);
        break;
      }

      case 'customer.subscription.updated':
      case 'customer.subscription.created': {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionUpdate(subscription);
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        await handleSubscriptionCancelled(subscription);
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        await handlePaymentFailed(invoice);
        break;
      }

      default:
        logger.debug(`Unhandled webhook event: ${event.type}`);
    }
  },

  /**
   * Create billing portal session
   */
  createPortalSession: async (userId: string, returnUrl: string): Promise<string> => {
    if (!stripe) throw new Error('Stripe not configured');

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { stripeCustomerId: true },
    });

    if (!user?.stripeCustomerId) {
      throw new Error('No Stripe customer found');
    }

    const session = await stripe.billingPortal.sessions.create({
      customer: user.stripeCustomerId,
      return_url: returnUrl,
    });

    return session.url;
  },

  /**
   * Construct webhook event from raw body
   */
  constructWebhookEvent: (body: Buffer, signature: string): Stripe.Event => {
    if (!stripe || !config.stripe.webhookSecret) {
      throw new Error('Stripe webhook not configured');
    }

    return stripe.webhooks.constructEvent(body, signature, config.stripe.webhookSecret);
  },
};

// =============================================================================
// WEBHOOK HANDLERS
// =============================================================================

async function handleCheckoutComplete(session: Stripe.Checkout.Session) {
  const { userId, ticketTypeId, quantity } = session.metadata || {};

  if (!userId || !ticketTypeId || !quantity) {
    logger.error('Missing metadata in checkout session');
    return;
  }

  const ticket = await prisma.ticketType.findUnique({
    where: { id: ticketTypeId },
  });

  if (!ticket) {
    logger.error(`Ticket type not found: ${ticketTypeId}`);
    return;
  }

  // Create purchase record
  await prisma.purchase.create({
    data: {
      userId,
      ticketTypeId,
      quantity: parseInt(quantity, 10),
      unitPriceCents: ticket.priceCents,
      totalCents: session.amount_total || 0,
      platformFeeCents: Math.round((session.amount_total || 0) * 0.02),
      stripePaymentIntentId: session.payment_intent as string,
      status: 'COMPLETED',
    },
  });

  // Update ticket quantity sold
  await prisma.ticketType.update({
    where: { id: ticketTypeId },
    data: {
      quantitySold: {
        increment: parseInt(quantity, 10),
      },
    },
  });

  // Add user as event attendee
  const ticketWithEvent = await prisma.ticketType.findUnique({
    where: { id: ticketTypeId },
    include: { event: true },
  });

  if (ticketWithEvent) {
    await prisma.eventAttendee.upsert({
      where: {
        eventId_userId: {
          eventId: ticketWithEvent.eventId,
          userId,
        },
      },
      create: {
        eventId: ticketWithEvent.eventId,
        userId,
        status: 'GOING',
      },
      update: {
        status: 'GOING',
      },
    });

    // Update attendee count
    await prisma.event.update({
      where: { id: ticketWithEvent.eventId },
      data: {
        attendeeCount: {
          increment: 1,
        },
      },
    });
  }

  logger.info(`Purchase completed: ${userId} bought ${quantity} tickets`);
}

async function handleSubscriptionUpdate(subscription: Stripe.Subscription) {
  const userId = subscription.metadata?.userId;
  
  if (!userId) {
    // Try to find user by customer ID
    const user = await prisma.user.findFirst({
      where: { stripeCustomerId: subscription.customer as string },
    });
    
    if (!user) {
      logger.error('User not found for subscription update');
      return;
    }
  }

  // Determine tier from price
  const priceId = subscription.items.data[0]?.price.id;
  let tier: SubscriptionTier = 'FREE';

  if (priceId === config.stripe.prices.connectMonthly) {
    tier = 'CONNECT';
  } else if (priceId === config.stripe.prices.creatorMonthly) {
    tier = 'CREATOR';
  }

  // Update user subscription
  await prisma.user.updateMany({
    where: {
      OR: [
        { id: userId || '' },
        { stripeCustomerId: subscription.customer as string },
      ],
    },
    data: {
      subscriptionTier: tier,
      stripeSubscriptionId: subscription.id,
      subscriptionEndsAt: new Date(subscription.current_period_end * 1000),
    },
  });

  logger.info(`Subscription updated: ${tier}`);
}

async function handleSubscriptionCancelled(subscription: Stripe.Subscription) {
  await prisma.user.updateMany({
    where: { stripeSubscriptionId: subscription.id },
    data: {
      subscriptionTier: 'FREE',
      stripeSubscriptionId: null,
      subscriptionEndsAt: null,
    },
  });

  logger.info(`Subscription cancelled: ${subscription.id}`);
}

async function handlePaymentFailed(invoice: Stripe.Invoice) {
  const customerId = invoice.customer as string;

  const user = await prisma.user.findFirst({
    where: { stripeCustomerId: customerId },
    select: { id: true, email: true, name: true },
  });

  if (user) {
    // TODO: Send payment failed email
    logger.warn(`Payment failed for user ${user.id}`);
  }
}

// =============================================================================
// EMAIL SERVICE
// =============================================================================

import { Resend } from 'resend';
import { config } from '../config/env';
import { logger } from '../utils/logger';

// Initialize Resend client
const resend = config.email.resendApiKey ? new Resend(config.email.resendApiKey) : null;

// =============================================================================
// EMAIL TEMPLATES
// =============================================================================

const templates = {
  welcome: (name: string) => ({
    subject: `Welcome to ${config.appName}! 🎉`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #FF6B35; margin: 0;">Welcome to ${config.appName}!</h1>
          </div>
          <p>Hey ${name},</p>
          <p>Thanks for joining ${config.appName}! We're excited to have you as part of our community.</p>
          <p>Here's what you can do next:</p>
          <ul>
            <li><strong>Discover Events</strong> - Find amazing events happening near you</li>
            <li><strong>Create Your QR Profile</strong> - Share all your social links with one scan</li>
            <li><strong>Connect with Others</strong> - Follow hosts and meet new people</li>
          </ul>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${config.appUrl}" style="background: linear-gradient(135deg, #FF6B35, #FF8F65); color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600; display: inline-block;">
              Explore Events
            </a>
          </div>
          <p>Cheers,<br>The ${config.appName} Team</p>
        </body>
      </html>
    `,
  }),

  passwordReset: (name: string, resetToken: string) => ({
    subject: `Reset your ${config.appName} password`,
    html: `
      <!DOCTYPE html>
      <html>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #FF6B35;">Reset Your Password</h1>
          <p>Hey ${name},</p>
          <p>We received a request to reset your password. Click the button below:</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${config.appUrl}/reset-password?token=${resetToken}" style="background: #FF6B35; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600;">
              Reset Password
            </a>
          </div>
          <p>This link expires in 1 hour. If you didn't request this, ignore this email.</p>
          <p>Cheers,<br>The ${config.appName} Team</p>
        </body>
      </html>
    `,
  }),

  emailVerification: (name: string, verificationToken: string) => ({
    subject: `Verify your ${config.appName} email`,
    html: `
      <!DOCTYPE html>
      <html>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #FF6B35;">Verify Your Email</h1>
          <p>Hey ${name},</p>
          <p>Please verify your email address by clicking the button below:</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${config.appUrl}/verify-email?token=${verificationToken}" style="background: #FF6B35; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600;">
              Verify Email
            </a>
          </div>
          <p>This link expires in 24 hours.</p>
          <p>Cheers,<br>The ${config.appName} Team</p>
        </body>
      </html>
    `,
  }),

  eventReminder: (name: string, eventTitle: string, eventDate: string, eventTime: string) => ({
    subject: `Reminder: ${eventTitle} is coming up! 🎉`,
    html: `
      <!DOCTYPE html>
      <html>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #FF6B35;">Event Reminder</h1>
          <p>Hey ${name},</p>
          <p>Just a friendly reminder that <strong>${eventTitle}</strong> is coming up!</p>
          <div style="background: #f8f9fa; border-radius: 12px; padding: 20px; margin: 20px 0;">
            <p style="margin: 0;"><strong>📅 Date:</strong> ${eventDate}</p>
            <p style="margin: 10px 0 0 0;"><strong>🕐 Time:</strong> ${eventTime}</p>
          </div>
          <p>We can't wait to see you there!</p>
          <p>Cheers,<br>The ${config.appName} Team</p>
        </body>
      </html>
    `,
  }),

  ticketConfirmation: (name: string, eventTitle: string, ticketType: string, quantity: number) => ({
    subject: `Your tickets for ${eventTitle} 🎟️`,
    html: `
      <!DOCTYPE html>
      <html>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #FF6B35;">You're Going! 🎉</h1>
          <p>Hey ${name},</p>
          <p>Your tickets for <strong>${eventTitle}</strong> have been confirmed!</p>
          <div style="background: #f8f9fa; border-radius: 12px; padding: 20px; margin: 20px 0;">
            <p style="margin: 0;"><strong>🎟️ Ticket Type:</strong> ${ticketType}</p>
            <p style="margin: 10px 0 0 0;"><strong>👥 Quantity:</strong> ${quantity}</p>
          </div>
          <p>Your tickets will be available in the app. Just show your QR code at the door!</p>
          <p>See you there!</p>
          <p>Cheers,<br>The ${config.appName} Team</p>
        </body>
      </html>
    `,
  }),
};

// =============================================================================
// EMAIL SERVICE
// =============================================================================

export const emailService = {
  send: async (to: string, subject: string, html: string): Promise<boolean> => {
    if (!resend) {
      logger.warn('Email service not configured (RESEND_API_KEY missing)');
      if (config.isDevelopment) {
        logger.info(`[DEV] Would send email to ${to}: ${subject}`);
      }
      return false;
    }

    try {
      await resend.emails.send({
        from: config.email.from,
        to,
        subject,
        html,
      });
      logger.info(`Email sent to ${to}: ${subject}`);
      return true;
    } catch (error) {
      logger.error('Failed to send email:', error);
      return false;
    }
  },

  sendWelcomeEmail: async (to: string, name: string): Promise<boolean> => {
    const { subject, html } = templates.welcome(name);
    return emailService.send(to, subject, html);
  },

  sendPasswordResetEmail: async (to: string, name: string, token: string): Promise<boolean> => {
    const { subject, html } = templates.passwordReset(name, token);
    return emailService.send(to, subject, html);
  },

  sendVerificationEmail: async (to: string, name: string, token: string): Promise<boolean> => {
    const { subject, html } = templates.emailVerification(name, token);
    return emailService.send(to, subject, html);
  },

  sendEventReminder: async (
    to: string,
    name: string,
    eventTitle: string,
    eventDate: string,
    eventTime: string
  ): Promise<boolean> => {
    const { subject, html } = templates.eventReminder(name, eventTitle, eventDate, eventTime);
    return emailService.send(to, subject, html);
  },

  sendTicketConfirmation: async (
    to: string,
    name: string,
    eventTitle: string,
    ticketType: string,
    quantity: number
  ): Promise<boolean> => {
    const { subject, html } = templates.ticketConfirmation(name, eventTitle, ticketType, quantity);
    return emailService.send(to, subject, html);
  },
};

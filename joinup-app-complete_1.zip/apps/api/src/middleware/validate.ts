// =============================================================================
// VALIDATION MIDDLEWARE
// =============================================================================

import { Request, Response, NextFunction } from 'express';
import { AnyZodObject, ZodError } from 'zod';
import { ValidationError } from './errorHandler';

/**
 * Middleware to validate request against a Zod schema
 */
export const validate = (schema: AnyZodObject) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      await schema.parseAsync({
        body: req.body,
        query: req.query,
        params: req.params,
      });
      
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        const errors: Record<string, string[]> = {};
        
        error.errors.forEach((err) => {
          // Remove 'body.', 'query.', 'params.' prefix from path
          const path = err.path.slice(1).join('.') || 'value';
          
          if (!errors[path]) {
            errors[path] = [];
          }
          errors[path].push(err.message);
        });

        return next(new ValidationError('Validation failed', errors));
      }
      
      next(error);
    }
  };
};

/**
 * Validate request body only
 */
export const validateBody = (schema: AnyZodObject) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      req.body = await schema.parseAsync(req.body);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        const errors: Record<string, string[]> = {};
        
        error.errors.forEach((err) => {
          const path = err.path.join('.') || 'value';
          if (!errors[path]) {
            errors[path] = [];
          }
          errors[path].push(err.message);
        });

        return next(new ValidationError('Validation failed', errors));
      }
      
      next(error);
    }
  };
};

/**
 * Validate query parameters only
 */
export const validateQuery = (schema: AnyZodObject) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      req.query = await schema.parseAsync(req.query);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        const errors: Record<string, string[]> = {};
        
        error.errors.forEach((err) => {
          const path = err.path.join('.') || 'value';
          if (!errors[path]) {
            errors[path] = [];
          }
          errors[path].push(err.message);
        });

        return next(new ValidationError('Invalid query parameters', errors));
      }
      
      next(error);
    }
  };
};

/**
 * Validate URL parameters only
 */
export const validateParams = (schema: AnyZodObject) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      req.params = await schema.parseAsync(req.params);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        const errors: Record<string, string[]> = {};
        
        error.errors.forEach((err) => {
          const path = err.path.join('.') || 'value';
          if (!errors[path]) {
            errors[path] = [];
          }
          errors[path].push(err.message);
        });

        return next(new ValidationError('Invalid URL parameters', errors));
      }
      
      next(error);
    }
  };
};

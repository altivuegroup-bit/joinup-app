// =============================================================================
// RATE LIMITER MIDDLEWARE
// =============================================================================

import rateLimit from 'express-rate-limit';
import { Request, Response } from 'express';
import { config } from '../config/env';
import { logger } from '../utils/logger';

// =============================================================================
// RATE LIMIT RESPONSE
// =============================================================================

const rateLimitResponse = (req: Request, res: Response) => {
  logger.warn(`Rate limit exceeded: ${req.ip} - ${req.path}`);
  
  res.status(429).json({
    success: false,
    error: {
      message: 'Too many requests, please try again later',
      code: 'RATE_LIMIT_EXCEEDED',
      retryAfter: Math.ceil(config.rateLimit.windowMs / 1000),
    },
  });
};

// =============================================================================
// GENERAL API RATE LIMITER
// =============================================================================

export const rateLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.maxRequests,
  message: { error: 'Too many requests' },
  standardHeaders: true,
  legacyHeaders: false,
  handler: rateLimitResponse,
  skip: (req) => {
    // Skip rate limiting for health checks
    return req.path === '/health' || req.path === '/api/health';
  },
  keyGenerator: (req) => {
    // Use user ID if authenticated, otherwise IP
    return (req as any).user?.id || req.ip || 'unknown';
  },
});

// =============================================================================
// AUTH RATE LIMITER (Stricter)
// =============================================================================

export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: config.rateLimit.authMax,
  message: { error: 'Too many authentication attempts' },
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req: Request, res: Response) => {
    logger.warn(`Auth rate limit exceeded: ${req.ip}`);
    
    res.status(429).json({
      success: false,
      error: {
        message: 'Too many authentication attempts, please try again later',
        code: 'AUTH_RATE_LIMIT_EXCEEDED',
        retryAfter: 900, // 15 minutes
      },
    });
  },
  skipSuccessfulRequests: true,
});

// =============================================================================
// UPLOAD RATE LIMITER
// =============================================================================

export const uploadRateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 50, // 50 uploads per hour
  message: { error: 'Too many uploads' },
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req: Request, res: Response) => {
    logger.warn(`Upload rate limit exceeded: ${req.ip}`);
    
    res.status(429).json({
      success: false,
      error: {
        message: 'Too many uploads, please try again later',
        code: 'UPLOAD_RATE_LIMIT_EXCEEDED',
        retryAfter: 3600, // 1 hour
      },
    });
  },
});

// =============================================================================
// PAYMENT RATE LIMITER
// =============================================================================

export const paymentRateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 20, // 20 payment attempts per hour
  message: { error: 'Too many payment attempts' },
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req: Request, res: Response) => {
    logger.warn(`Payment rate limit exceeded: ${req.ip}`);
    
    res.status(429).json({
      success: false,
      error: {
        message: 'Too many payment attempts, please try again later',
        code: 'PAYMENT_RATE_LIMIT_EXCEEDED',
        retryAfter: 3600,
      },
    });
  },
});

// =============================================================================
// AUTHENTICATION MIDDLEWARE
// =============================================================================

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config/env';
import { prisma } from '../utils/prisma';
import { UnauthorizedError, ForbiddenError } from './errorHandler';
import { SubscriptionTier } from '@prisma/client';

// =============================================================================
// TYPES
// =============================================================================

export interface JwtPayload {
  userId: string;
  email: string;
  type: 'access' | 'refresh';
}

export interface AuthenticatedRequest extends Request {
  user: {
    id: string;
    email: string;
    name: string;
    username: string;
    subscriptionTier: SubscriptionTier;
  };
}

// =============================================================================
// AUTHENTICATE MIDDLEWARE
// =============================================================================

export const authenticate = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    // Get token from header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedError('No token provided');
    }

    const token = authHeader.split(' ')[1];

    // Verify token
    const decoded = jwt.verify(token, config.jwt.accessSecret) as JwtPayload;

    if (decoded.type !== 'access') {
      throw new UnauthorizedError('Invalid token type');
    }

    // Get user from database
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        name: true,
        username: true,
        subscriptionTier: true,
        isActive: true,
      },
    });

    if (!user) {
      throw new UnauthorizedError('User not found');
    }

    if (!user.isActive) {
      throw new UnauthorizedError('Account is deactivated');
    }

    // Attach user to request
    (req as AuthenticatedRequest).user = {
      id: user.id,
      email: user.email,
      name: user.name,
      username: user.username,
      subscriptionTier: user.subscriptionTier,
    };

    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return next(new UnauthorizedError('Invalid token'));
    }
    if (error instanceof jwt.TokenExpiredError) {
      return next(new UnauthorizedError('Token expired'));
    }
    next(error);
  }
};

// =============================================================================
// OPTIONAL AUTH MIDDLEWARE
// =============================================================================

export const optionalAuth = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next();
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, config.jwt.accessSecret) as JwtPayload;

    if (decoded.type !== 'access') {
      return next();
    }

    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        name: true,
        username: true,
        subscriptionTier: true,
        isActive: true,
      },
    });

    if (user && user.isActive) {
      (req as AuthenticatedRequest).user = {
        id: user.id,
        email: user.email,
        name: user.name,
        username: user.username,
        subscriptionTier: user.subscriptionTier,
      };
    }

    next();
  } catch {
    // Ignore errors and continue without auth
    next();
  }
};

// =============================================================================
// REQUIRE SUBSCRIPTION MIDDLEWARE
// =============================================================================

export const requireSubscription = (minTier: SubscriptionTier) => {
  const tierOrder: Record<SubscriptionTier, number> = {
    FREE: 0,
    CONNECT: 1,
    CREATOR: 2,
  };

  return (req: Request, res: Response, next: NextFunction) => {
    const user = (req as AuthenticatedRequest).user;

    if (!user) {
      return next(new UnauthorizedError('Authentication required'));
    }

    const userTierLevel = tierOrder[user.subscriptionTier];
    const requiredTierLevel = tierOrder[minTier];

    if (userTierLevel < requiredTierLevel) {
      return next(
        new ForbiddenError(
          `This feature requires a ${minTier} subscription or higher`
        )
      );
    }

    next();
  };
};

// =============================================================================
// REQUIRE VERIFIED EMAIL
// =============================================================================

export const requireVerifiedEmail = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const user = (req as AuthenticatedRequest).user;

  if (!user) {
    return next(new UnauthorizedError('Authentication required'));
  }

  const fullUser = await prisma.user.findUnique({
    where: { id: user.id },
    select: { emailVerified: true },
  });

  if (!fullUser?.emailVerified) {
    return next(new ForbiddenError('Please verify your email address first'));
  }

  next();
};

// =============================================================================
// TOKEN GENERATION HELPERS
// =============================================================================

export const generateAccessToken = (user: { id: string; email: string }): string => {
  const payload: JwtPayload = {
    userId: user.id,
    email: user.email,
    type: 'access',
  };

  return jwt.sign(payload, config.jwt.accessSecret, {
    expiresIn: config.jwt.accessExpiresIn,
  });
};

export const generateRefreshToken = (user: { id: string; email: string }): string => {
  const payload: JwtPayload = {
    userId: user.id,
    email: user.email,
    type: 'refresh',
  };

  return jwt.sign(payload, config.jwt.refreshSecret, {
    expiresIn: config.jwt.refreshExpiresIn,
  });
};

export const verifyRefreshToken = (token: string): JwtPayload => {
  const decoded = jwt.verify(token, config.jwt.refreshSecret) as JwtPayload;
  
  if (decoded.type !== 'refresh') {
    throw new Error('Invalid token type');
  }
  
  return decoded;
};

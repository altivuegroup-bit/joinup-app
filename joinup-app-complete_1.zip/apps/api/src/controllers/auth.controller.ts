// =============================================================================
// AUTHENTICATION CONTROLLER
// =============================================================================

import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcrypt';
import { prisma } from '../utils/prisma';
import { config } from '../config/env';
import { logger } from '../utils/logger';
import { generateToken, sha256 } from '../utils/encryption';
import {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
  AuthenticatedRequest,
} from '../middleware/auth';
import {
  BadRequestError,
  UnauthorizedError,
  ConflictError,
  NotFoundError,
} from '../middleware/errorHandler';
import { emailService } from '../services/email.service';
import type {
  RegisterInput,
  LoginInput,
  RefreshTokenInput,
  ForgotPasswordInput,
  ResetPasswordInput,
  ChangePasswordInput,
  VerifyEmailInput,
} from '../validators/auth.validators';

// =============================================================================
// CONSTANTS
// =============================================================================

const SALT_ROUNDS = 12;
const REFRESH_TOKEN_EXPIRY_DAYS = 7;
const PASSWORD_RESET_EXPIRY_HOURS = 1;
const EMAIL_VERIFICATION_EXPIRY_HOURS = 24;

// =============================================================================
// CONTROLLER
// =============================================================================

export const authController = {
  // ===========================================================================
  // REGISTER
  // ===========================================================================
  register: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email, password, name, username } = req.body as RegisterInput;

      // Check if email already exists
      const existingEmail = await prisma.user.findUnique({
        where: { email },
        select: { id: true },
      });

      if (existingEmail) {
        throw new ConflictError('Email already registered');
      }

      // Check if username already exists
      const existingUsername = await prisma.user.findUnique({
        where: { username },
        select: { id: true },
      });

      if (existingUsername) {
        throw new ConflictError('Username already taken');
      }

      // Hash password
      const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

      // Create user
      const user = await prisma.user.create({
        data: {
          email,
          passwordHash,
          name,
          username,
        },
        select: {
          id: true,
          email: true,
          name: true,
          username: true,
          subscriptionTier: true,
          createdAt: true,
        },
      });

      // Generate tokens
      const accessToken = generateAccessToken(user);
      const refreshToken = generateRefreshToken(user);

      // Store refresh token
      const refreshTokenExpiry = new Date();
      refreshTokenExpiry.setDate(refreshTokenExpiry.getDate() + REFRESH_TOKEN_EXPIRY_DAYS);

      await prisma.refreshToken.create({
        data: {
          token: sha256(refreshToken),
          userId: user.id,
          expiresAt: refreshTokenExpiry,
        },
      });

      // Send verification email (async, don't await)
      const verificationToken = generateToken(32);
      // TODO: Store verification token and send email
      emailService.sendWelcomeEmail(user.email, user.name).catch((err) => {
        logger.error('Failed to send welcome email:', err);
      });

      logger.info(`New user registered: ${user.id}`);

      res.status(201).json({
        success: true,
        data: {
          user,
          accessToken,
          refreshToken,
        },
      });
    } catch (error) {
      next(error);
    }
  },

  // ===========================================================================
  // LOGIN
  // ===========================================================================
  login: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email, password } = req.body as LoginInput;

      // Find user
      const user = await prisma.user.findUnique({
        where: { email },
        select: {
          id: true,
          email: true,
          name: true,
          username: true,
          passwordHash: true,
          subscriptionTier: true,
          isActive: true,
          avatarUrl: true,
        },
      });

      if (!user) {
        throw new UnauthorizedError('Invalid email or password');
      }

      if (!user.isActive) {
        throw new UnauthorizedError('Account is deactivated');
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(password, user.passwordHash);

      if (!isValidPassword) {
        throw new UnauthorizedError('Invalid email or password');
      }

      // Generate tokens
      const accessToken = generateAccessToken(user);
      const refreshToken = generateRefreshToken(user);

      // Store refresh token
      const refreshTokenExpiry = new Date();
      refreshTokenExpiry.setDate(refreshTokenExpiry.getDate() + REFRESH_TOKEN_EXPIRY_DAYS);

      await prisma.refreshToken.create({
        data: {
          token: sha256(refreshToken),
          userId: user.id,
          expiresAt: refreshTokenExpiry,
        },
      });

      // Update last login
      await prisma.user.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() },
      });

      logger.info(`User logged in: ${user.id}`);

      // Return user without password hash
      const { passwordHash, ...userWithoutPassword } = user;

      res.json({
        success: true,
        data: {
          user: userWithoutPassword,
          accessToken,
          refreshToken,
        },
      });
    } catch (error) {
      next(error);
    }
  },

  // ===========================================================================
  // REFRESH TOKEN
  // ===========================================================================
  refreshToken: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { refreshToken } = req.body as RefreshTokenInput;

      // Verify refresh token
      let decoded;
      try {
        decoded = verifyRefreshToken(refreshToken);
      } catch {
        throw new UnauthorizedError('Invalid refresh token');
      }

      // Check if token exists in database
      const hashedToken = sha256(refreshToken);
      const storedToken = await prisma.refreshToken.findUnique({
        where: { token: hashedToken },
        include: {
          user: {
            select: {
              id: true,
              email: true,
              name: true,
              username: true,
              subscriptionTier: true,
              isActive: true,
            },
          },
        },
      });

      if (!storedToken) {
        throw new UnauthorizedError('Refresh token not found');
      }

      if (storedToken.expiresAt < new Date()) {
        // Delete expired token
        await prisma.refreshToken.delete({ where: { id: storedToken.id } });
        throw new UnauthorizedError('Refresh token expired');
      }

      if (!storedToken.user.isActive) {
        throw new UnauthorizedError('Account is deactivated');
      }

      // Generate new tokens
      const newAccessToken = generateAccessToken(storedToken.user);
      const newRefreshToken = generateRefreshToken(storedToken.user);

      // Update refresh token (rotate)
      const refreshTokenExpiry = new Date();
      refreshTokenExpiry.setDate(refreshTokenExpiry.getDate() + REFRESH_TOKEN_EXPIRY_DAYS);

      await prisma.refreshToken.update({
        where: { id: storedToken.id },
        data: {
          token: sha256(newRefreshToken),
          expiresAt: refreshTokenExpiry,
        },
      });

      res.json({
        success: true,
        data: {
          accessToken: newAccessToken,
          refreshToken: newRefreshToken,
        },
      });
    } catch (error) {
      next(error);
    }
  },

  // ===========================================================================
  // GET CURRENT USER
  // ===========================================================================
  getCurrentUser: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { user } = req as AuthenticatedRequest;

      const fullUser = await prisma.user.findUnique({
        where: { id: user.id },
        select: {
          id: true,
          email: true,
          name: true,
          username: true,
          bio: true,
          avatarUrl: true,
          coverImageUrl: true,
          subscriptionTier: true,
          emailVerified: true,
          createdAt: true,
          _count: {
            select: {
              hostedEvents: true,
              eventAttendances: true,
              followers: true,
              following: true,
            },
          },
          socialConnections: {
            select: {
              platform: true,
              platformUsername: true,
              isPublic: true,
            },
          },
        },
      });

      if (!fullUser) {
        throw new NotFoundError('User not found');
      }

      res.json({
        success: true,
        data: { user: fullUser },
      });
    } catch (error) {
      next(error);
    }
  },

  // ===========================================================================
  // LOGOUT
  // ===========================================================================
  logout: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { user } = req as AuthenticatedRequest;

      // Get refresh token from body or delete all user's tokens
      const refreshToken = req.body.refreshToken;

      if (refreshToken) {
        // Delete specific token
        await prisma.refreshToken.deleteMany({
          where: {
            token: sha256(refreshToken),
            userId: user.id,
          },
        });
      } else {
        // Delete all user's refresh tokens (logout from all devices)
        await prisma.refreshToken.deleteMany({
          where: { userId: user.id },
        });
      }

      logger.info(`User logged out: ${user.id}`);

      res.json({
        success: true,
        message: 'Logged out successfully',
      });
    } catch (error) {
      next(error);
    }
  },

  // ===========================================================================
  // FORGOT PASSWORD
  // ===========================================================================
  forgotPassword: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email } = req.body as ForgotPasswordInput;

      // Find user (don't reveal if user exists or not)
      const user = await prisma.user.findUnique({
        where: { email },
        select: { id: true, name: true, email: true },
      });

      if (user) {
        // Generate reset token
        const resetToken = generateToken(32);
        const resetTokenExpiry = new Date();
        resetTokenExpiry.setHours(resetTokenExpiry.getHours() + PASSWORD_RESET_EXPIRY_HOURS);

        // TODO: Store reset token in database
        // For now, just log it
        logger.info(`Password reset requested for: ${user.id}`);

        // Send email
        await emailService.sendPasswordResetEmail(user.email, user.name, resetToken);
      }

      // Always return success (security: don't reveal if email exists)
      res.json({
        success: true,
        message: 'If an account exists with this email, a password reset link has been sent',
      });
    } catch (error) {
      next(error);
    }
  },

  // ===========================================================================
  // RESET PASSWORD
  // ===========================================================================
  resetPassword: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { token, password } = req.body as ResetPasswordInput;

      // TODO: Verify reset token from database
      // For now, throw error
      throw new BadRequestError('Invalid or expired reset token');

      // Hash new password
      // const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

      // Update password
      // Delete all refresh tokens (force re-login)

      res.json({
        success: true,
        message: 'Password reset successfully',
      });
    } catch (error) {
      next(error);
    }
  },

  // ===========================================================================
  // CHANGE PASSWORD
  // ===========================================================================
  changePassword: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { user } = req as AuthenticatedRequest;
      const { currentPassword, newPassword } = req.body as ChangePasswordInput;

      // Get user with password
      const fullUser = await prisma.user.findUnique({
        where: { id: user.id },
        select: { passwordHash: true },
      });

      if (!fullUser) {
        throw new NotFoundError('User not found');
      }

      // Verify current password
      const isValidPassword = await bcrypt.compare(currentPassword, fullUser.passwordHash);

      if (!isValidPassword) {
        throw new BadRequestError('Current password is incorrect');
      }

      // Hash new password
      const passwordHash = await bcrypt.hash(newPassword, SALT_ROUNDS);

      // Update password
      await prisma.user.update({
        where: { id: user.id },
        data: { passwordHash },
      });

      // Invalidate all refresh tokens
      await prisma.refreshToken.deleteMany({
        where: { userId: user.id },
      });

      logger.info(`Password changed for user: ${user.id}`);

      res.json({
        success: true,
        message: 'Password changed successfully. Please log in again.',
      });
    } catch (error) {
      next(error);
    }
  },

  // ===========================================================================
  // VERIFY EMAIL
  // ===========================================================================
  verifyEmail: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { token } = req.body as VerifyEmailInput;

      // TODO: Verify token from database
      throw new BadRequestError('Invalid or expired verification token');

      res.json({
        success: true,
        message: 'Email verified successfully',
      });
    } catch (error) {
      next(error);
    }
  },

  // ===========================================================================
  // RESEND VERIFICATION
  // ===========================================================================
  resendVerification: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { user } = req as AuthenticatedRequest;

      const fullUser = await prisma.user.findUnique({
        where: { id: user.id },
        select: { email: true, name: true, emailVerified: true },
      });

      if (!fullUser) {
        throw new NotFoundError('User not found');
      }

      if (fullUser.emailVerified) {
        throw new BadRequestError('Email is already verified');
      }

      // Generate new verification token
      const verificationToken = generateToken(32);

      // TODO: Store token and send email

      res.json({
        success: true,
        message: 'Verification email sent',
      });
    } catch (error) {
      next(error);
    }
  },

  // ===========================================================================
  // DELETE ACCOUNT
  // ===========================================================================
  deleteAccount: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { user } = req as AuthenticatedRequest;
      const { password } = req.body;

      if (!password) {
        throw new BadRequestError('Password is required to delete account');
      }

      // Verify password
      const fullUser = await prisma.user.findUnique({
        where: { id: user.id },
        select: { passwordHash: true },
      });

      if (!fullUser) {
        throw new NotFoundError('User not found');
      }

      const isValidPassword = await bcrypt.compare(password, fullUser.passwordHash);

      if (!isValidPassword) {
        throw new BadRequestError('Incorrect password');
      }

      // Delete user (cascades to related data)
      await prisma.user.delete({
        where: { id: user.id },
      });

      logger.info(`Account deleted: ${user.id}`);

      res.json({
        success: true,
        message: 'Account deleted successfully',
      });
    } catch (error) {
      next(error);
    }
  },
};

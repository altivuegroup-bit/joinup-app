// =============================================================================
// NOTIFICATION ROUTES
// =============================================================================

import { Router } from 'express';
import { notificationController } from '../controllers/notification.controller';
import { authenticate } from '../middleware/auth';

const router = Router();

/**
 * @route   GET /api/notifications
 * @desc    Get user's notifications (paginated)
 * @access  Private
 */
router.get('/', authenticate, notificationController.getNotifications);

/**
 * @route   GET /api/notifications/unread-count
 * @desc    Get unread notification count
 * @access  Private
 */
router.get('/unread-count', authenticate, notificationController.getUnreadCount);

/**
 * @route   POST /api/notifications/:id/read
 * @desc    Mark notification as read
 * @access  Private
 */
router.post('/:id/read', authenticate, notificationController.markAsRead);

/**
 * @route   POST /api/notifications/read-all
 * @desc    Mark all notifications as read
 * @access  Private
 */
router.post('/read-all', authenticate, notificationController.markAllAsRead);

/**
 * @route   DELETE /api/notifications/:id
 * @desc    Delete a notification
 * @access  Private
 */
router.delete('/:id', authenticate, notificationController.deleteNotification);

/**
 * @route   POST /api/notifications/push-token
 * @desc    Register push notification token
 * @access  Private
 */
router.post('/push-token', authenticate, notificationController.registerPushToken);

/**
 * @route   DELETE /api/notifications/push-token
 * @desc    Unregister push notification token
 * @access  Private
 */
router.delete('/push-token', authenticate, notificationController.unregisterPushToken);

export default router;

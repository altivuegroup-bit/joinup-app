// =============================================================================
// CHAT ROUTES
// =============================================================================

import { Router } from 'express';
import { chatController } from '../controllers/chat.controller';
import { authenticate } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { createChatSchema, sendMessageSchema } from '../validators/chat.validators';

const router = Router();

/**
 * @route   GET /api/chats
 * @desc    Get user's chats
 * @access  Private
 */
router.get('/', authenticate, chatController.getChats);

/**
 * @route   POST /api/chats
 * @desc    Create a new chat (DM or group)
 * @access  Private
 */
router.post('/', authenticate, validate(createChatSchema), chatController.createChat);

/**
 * @route   GET /api/chats/:id
 * @desc    Get chat by ID
 * @access  Private
 */
router.get('/:id', authenticate, chatController.getChat);

/**
 * @route   GET /api/chats/:id/messages
 * @desc    Get chat messages (paginated)
 * @access  Private
 */
router.get('/:id/messages', authenticate, chatController.getMessages);

/**
 * @route   POST /api/chats/:id/messages
 * @desc    Send a message
 * @access  Private
 */
router.post(
  '/:id/messages',
  authenticate,
  validate(sendMessageSchema),
  chatController.sendMessage
);

/**
 * @route   POST /api/chats/:id/read
 * @desc    Mark chat as read
 * @access  Private
 */
router.post('/:id/read', authenticate, chatController.markAsRead);

/**
 * @route   POST /api/chats/:id/leave
 * @desc    Leave a group chat
 * @access  Private
 */
router.post('/:id/leave', authenticate, chatController.leaveChat);

/**
 * @route   POST /api/chats/:id/mute
 * @desc    Mute/unmute chat notifications
 * @access  Private
 */
router.post('/:id/mute', authenticate, chatController.toggleMute);

export default router;

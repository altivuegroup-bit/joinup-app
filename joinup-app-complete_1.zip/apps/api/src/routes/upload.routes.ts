// =============================================================================
// UPLOAD ROUTES
// =============================================================================

import { Router } from 'express';
import { uploadController } from '../controllers/upload.controller';
import { authenticate } from '../middleware/auth';
import { uploadRateLimiter } from '../middleware/rateLimiter';
import multer from 'multer';

const router = Router();

// Configure multer for memory storage
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allow images only
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
});

/**
 * @route   POST /api/upload/image
 * @desc    Upload a single image
 * @access  Private
 */
router.post(
  '/image',
  authenticate,
  uploadRateLimiter,
  upload.single('image'),
  uploadController.uploadImage
);

/**
 * @route   POST /api/upload/images
 * @desc    Upload multiple images
 * @access  Private
 */
router.post(
  '/images',
  authenticate,
  uploadRateLimiter,
  upload.array('images', 10),
  uploadController.uploadImages
);

/**
 * @route   POST /api/upload/avatar
 * @desc    Upload user avatar
 * @access  Private
 */
router.post(
  '/avatar',
  authenticate,
  uploadRateLimiter,
  upload.single('avatar'),
  uploadController.uploadAvatar
);

/**
 * @route   DELETE /api/upload/:key
 * @desc    Delete an uploaded file
 * @access  Private
 */
router.delete('/:key', authenticate, uploadController.deleteFile);

export default router;

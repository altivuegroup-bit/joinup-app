// =============================================================================
// PAYMENT ROUTES
// =============================================================================

import { Router } from 'express';
import { paymentController } from '../controllers/payment.controller';
import { authenticate } from '../middleware/auth';
import { paymentRateLimiter } from '../middleware/rateLimiter';
import { validate } from '../middleware/validate';
import {
  createCheckoutSchema,
  createSubscriptionSchema,
} from '../validators/payment.validators';
import express from 'express';

const router = Router();

// =============================================================================
// STRIPE WEBHOOK (Must be before JSON parsing)
// =============================================================================

/**
 * @route   POST /api/payments/webhook
 * @desc    Stripe webhook handler
 * @access  Public (verified by Stripe signature)
 */
router.post(
  '/webhook',
  express.raw({ type: 'application/json' }),
  paymentController.handleWebhook
);

// =============================================================================
// PROTECTED ROUTES
// =============================================================================

/**
 * @route   POST /api/payments/checkout
 * @desc    Create checkout session for event tickets
 * @access  Private
 */
router.post(
  '/checkout',
  authenticate,
  paymentRateLimiter,
  validate(createCheckoutSchema),
  paymentController.createCheckout
);

/**
 * @route   POST /api/payments/subscription
 * @desc    Create or update subscription
 * @access  Private
 */
router.post(
  '/subscription',
  authenticate,
  paymentRateLimiter,
  validate(createSubscriptionSchema),
  paymentController.createSubscription
);

/**
 * @route   DELETE /api/payments/subscription
 * @desc    Cancel subscription
 * @access  Private
 */
router.delete('/subscription', authenticate, paymentController.cancelSubscription);

/**
 * @route   GET /api/payments/subscription
 * @desc    Get current subscription status
 * @access  Private
 */
router.get('/subscription', authenticate, paymentController.getSubscription);

/**
 * @route   GET /api/payments/history
 * @desc    Get payment history
 * @access  Private
 */
router.get('/history', authenticate, paymentController.getPaymentHistory);

/**
 * @route   POST /api/payments/portal
 * @desc    Create Stripe billing portal session
 * @access  Private
 */
router.post('/portal', authenticate, paymentController.createPortalSession);

/**
 * @route   GET /api/payments/connect/status
 * @desc    Get Stripe Connect status (for creators)
 * @access  Private
 */
router.get('/connect/status', authenticate, paymentController.getConnectStatus);

/**
 * @route   POST /api/payments/connect/onboard
 * @desc    Create Stripe Connect onboarding link
 * @access  Private
 */
router.post('/connect/onboard', authenticate, paymentController.createConnectOnboarding);

export default router;

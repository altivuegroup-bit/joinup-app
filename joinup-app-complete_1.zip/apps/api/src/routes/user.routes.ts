// =============================================================================
// USER ROUTES
// =============================================================================

import { Router } from 'express';
import { userController } from '../controllers/user.controller';
import { authenticate, optionalAuth } from '../middleware/auth';
import { validate } from '../middleware/validate';
import { updateProfileSchema, usernameParamSchema } from '../validators/user.validators';

const router = Router();

/**
 * @route   GET /api/users/:username
 * @desc    Get user profile by username
 * @access  Public (with optional auth for follow status)
 */
router.get('/:username', optionalAuth, userController.getProfile);

/**
 * @route   PUT /api/users/profile
 * @desc    Update current user's profile
 * @access  Private
 */
router.put('/profile', authenticate, validate(updateProfileSchema), userController.updateProfile);

/**
 * @route   POST /api/users/:id/follow
 * @desc    Follow a user
 * @access  Private
 */
router.post('/:id/follow', authenticate, userController.followUser);

/**
 * @route   DELETE /api/users/:id/follow
 * @desc    Unfollow a user
 * @access  Private
 */
router.delete('/:id/follow', authenticate, userController.unfollowUser);

/**
 * @route   GET /api/users/:id/followers
 * @desc    Get user's followers
 * @access  Public
 */
router.get('/:id/followers', optionalAuth, userController.getFollowers);

/**
 * @route   GET /api/users/:id/following
 * @desc    Get users that user is following
 * @access  Public
 */
router.get('/:id/following', optionalAuth, userController.getFollowing);

/**
 * @route   GET /api/users/:id/events
 * @desc    Get user's hosted events
 * @access  Public
 */
router.get('/:id/events', optionalAuth, userController.getUserEvents);

/**
 * @route   GET /api/users/suggestions
 * @desc    Get suggested users to follow
 * @access  Private
 */
router.get('/suggestions', authenticate, userController.getSuggestions);

export default router;

// =============================================================================
// HEALTH CHECK ROUTES
// =============================================================================

import { Router, Request, Response } from 'express';
import { prisma } from '../utils/prisma';

const router = Router();

// =============================================================================
// BASIC HEALTH CHECK
// =============================================================================

router.get('/', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'joinup-api',
    version: process.env.npm_package_version || '1.0.0',
  });
});

// =============================================================================
// DETAILED HEALTH CHECK
// =============================================================================

router.get('/detailed', async (req: Request, res: Response) => {
  const checks: Record<string, { status: string; latency?: number; error?: string }> = {};
  
  // Check database
  const dbStart = Date.now();
  try {
    await prisma.$queryRaw`SELECT 1`;
    checks.database = {
      status: 'healthy',
      latency: Date.now() - dbStart,
    };
  } catch (error) {
    checks.database = {
      status: 'unhealthy',
      error: error instanceof Error ? error.message : 'Unknown error',
    };
  }

  // Overall status
  const isHealthy = Object.values(checks).every((check) => check.status === 'healthy');

  res.status(isHealthy ? 200 : 503).json({
    status: isHealthy ? 'healthy' : 'unhealthy',
    timestamp: new Date().toISOString(),
    service: 'joinup-api',
    version: process.env.npm_package_version || '1.0.0',
    uptime: process.uptime(),
    checks,
  });
});

// =============================================================================
// READINESS CHECK (for Kubernetes)
// =============================================================================

router.get('/ready', async (req: Request, res: Response) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ ready: true });
  } catch {
    res.status(503).json({ ready: false });
  }
});

// =============================================================================
// LIVENESS CHECK (for Kubernetes)
// =============================================================================

router.get('/live', (req: Request, res: Response) => {
  res.json({ alive: true });
});

export default router;

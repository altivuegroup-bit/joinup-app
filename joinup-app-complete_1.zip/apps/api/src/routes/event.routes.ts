// =============================================================================
// EVENT ROUTES
// =============================================================================

import { Router } from 'express';
import { eventController } from '../controllers/event.controller';
import { authenticate, optionalAuth, requireSubscription } from '../middleware/auth';
import { validate } from '../middleware/validate';
import {
  createEventSchema,
  updateEventSchema,
  eventQuerySchema,
  eventIdParamSchema,
} from '../validators/event.validators';

const router = Router();

// =============================================================================
// PUBLIC ROUTES
// =============================================================================

/**
 * @route   GET /api/events
 * @desc    Get all events (paginated, filterable)
 * @access  Public
 */
router.get('/', optionalAuth, validate(eventQuerySchema), eventController.getEvents);

/**
 * @route   GET /api/events/featured
 * @desc    Get featured events
 * @access  Public
 */
router.get('/featured', optionalAuth, eventController.getFeaturedEvents);

/**
 * @route   GET /api/events/nearby
 * @desc    Get events near a location
 * @access  Public
 */
router.get('/nearby', optionalAuth, eventController.getNearbyEvents);

/**
 * @route   GET /api/events/categories
 * @desc    Get event categories with counts
 * @access  Public
 */
router.get('/categories', eventController.getCategories);

/**
 * @route   GET /api/events/:id
 * @desc    Get event by ID
 * @access  Public
 */
router.get('/:id', optionalAuth, eventController.getEvent);

/**
 * @route   GET /api/events/:id/attendees
 * @desc    Get event attendees
 * @access  Public
 */
router.get('/:id/attendees', optionalAuth, eventController.getAttendees);

/**
 * @route   GET /api/events/:id/reviews
 * @desc    Get event reviews
 * @access  Public
 */
router.get('/:id/reviews', eventController.getReviews);

// =============================================================================
// PROTECTED ROUTES
// =============================================================================

/**
 * @route   POST /api/events
 * @desc    Create a new event
 * @access  Private (Creator subscription required)
 */
router.post(
  '/',
  authenticate,
  requireSubscription('CREATOR'),
  validate(createEventSchema),
  eventController.createEvent
);

/**
 * @route   PUT /api/events/:id
 * @desc    Update an event
 * @access  Private (Owner only)
 */
router.put(
  '/:id',
  authenticate,
  validate(updateEventSchema),
  eventController.updateEvent
);

/**
 * @route   DELETE /api/events/:id
 * @desc    Delete an event
 * @access  Private (Owner only)
 */
router.delete('/:id', authenticate, eventController.deleteEvent);

/**
 * @route   POST /api/events/:id/publish
 * @desc    Publish a draft event
 * @access  Private (Owner only)
 */
router.post('/:id/publish', authenticate, eventController.publishEvent);

/**
 * @route   POST /api/events/:id/cancel
 * @desc    Cancel an event
 * @access  Private (Owner only)
 */
router.post('/:id/cancel', authenticate, eventController.cancelEvent);

/**
 * @route   POST /api/events/:id/join
 * @desc    Join an event (RSVP)
 * @access  Private
 */
router.post('/:id/join', authenticate, eventController.joinEvent);

/**
 * @route   DELETE /api/events/:id/join
 * @desc    Leave an event
 * @access  Private
 */
router.delete('/:id/join', authenticate, eventController.leaveEvent);

/**
 * @route   POST /api/events/:id/reviews
 * @desc    Add a review to an event
 * @access  Private (Must have attended)
 */
router.post('/:id/reviews', authenticate, eventController.addReview);

/**
 * @route   POST /api/events/:id/photos
 * @desc    Add photos to an event
 * @access  Private
 */
router.post('/:id/photos', authenticate, eventController.addPhotos);

export default router;

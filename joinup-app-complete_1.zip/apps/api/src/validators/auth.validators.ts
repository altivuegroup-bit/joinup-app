// =============================================================================
// AUTHENTICATION VALIDATORS
// =============================================================================

import { z } from 'zod';

// =============================================================================
// COMMON SCHEMAS
// =============================================================================

const emailSchema = z
  .string()
  .email('Invalid email address')
  .max(255, 'Email must be less than 255 characters')
  .transform((val) => val.toLowerCase().trim());

const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .max(100, 'Password must be less than 100 characters')
  .regex(
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
    'Password must contain at least one uppercase letter, one lowercase letter, and one number'
  );

const usernameSchema = z
  .string()
  .min(3, 'Username must be at least 3 characters')
  .max(30, 'Username must be less than 30 characters')
  .regex(
    /^[a-zA-Z0-9_]+$/,
    'Username can only contain letters, numbers, and underscores'
  )
  .transform((val) => val.toLowerCase().trim());

// =============================================================================
// REGISTER SCHEMA
// =============================================================================

export const registerSchema = z.object({
  body: z.object({
    email: emailSchema,
    password: passwordSchema,
    name: z
      .string()
      .min(2, 'Name must be at least 2 characters')
      .max(100, 'Name must be less than 100 characters')
      .trim(),
    username: usernameSchema,
  }),
});

export type RegisterInput = z.infer<typeof registerSchema>['body'];

// =============================================================================
// LOGIN SCHEMA
// =============================================================================

export const loginSchema = z.object({
  body: z.object({
    email: emailSchema,
    password: z.string().min(1, 'Password is required'),
  }),
});

export type LoginInput = z.infer<typeof loginSchema>['body'];

// =============================================================================
// REFRESH TOKEN SCHEMA
// =============================================================================

export const refreshTokenSchema = z.object({
  body: z.object({
    refreshToken: z.string().min(1, 'Refresh token is required'),
  }),
});

export type RefreshTokenInput = z.infer<typeof refreshTokenSchema>['body'];

// =============================================================================
// FORGOT PASSWORD SCHEMA
// =============================================================================

export const forgotPasswordSchema = z.object({
  body: z.object({
    email: emailSchema,
  }),
});

export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>['body'];

// =============================================================================
// RESET PASSWORD SCHEMA
// =============================================================================

export const resetPasswordSchema = z.object({
  body: z.object({
    token: z.string().min(1, 'Reset token is required'),
    password: passwordSchema,
  }),
});

export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>['body'];

// =============================================================================
// CHANGE PASSWORD SCHEMA
// =============================================================================

export const changePasswordSchema = z.object({
  body: z
    .object({
      currentPassword: z.string().min(1, 'Current password is required'),
      newPassword: passwordSchema,
      confirmPassword: z.string().min(1, 'Confirm password is required'),
    })
    .refine((data) => data.newPassword === data.confirmPassword, {
      message: 'Passwords do not match',
      path: ['confirmPassword'],
    })
    .refine((data) => data.currentPassword !== data.newPassword, {
      message: 'New password must be different from current password',
      path: ['newPassword'],
    }),
});

export type ChangePasswordInput = z.infer<typeof changePasswordSchema>['body'];

// =============================================================================
// VERIFY EMAIL SCHEMA
// =============================================================================

export const verifyEmailSchema = z.object({
  body: z.object({
    token: z.string().min(1, 'Verification token is required'),
  }),
});

export type VerifyEmailInput = z.infer<typeof verifyEmailSchema>['body'];

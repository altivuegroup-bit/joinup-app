// =============================================================================
// ENCRYPTION UTILITIES
// =============================================================================

import crypto from 'crypto';
import { config } from '../config/env';

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16;
const AUTH_TAG_LENGTH = 16;
const SALT_LENGTH = 32;

/**
 * Encrypt sensitive data (e.g., OAuth tokens)
 */
export const encrypt = (text: string): string => {
  const iv = crypto.randomBytes(IV_LENGTH);
  const key = Buffer.from(config.encryptionKey, 'hex');
  
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const authTag = cipher.getAuthTag();
  
  // Format: iv:authTag:encrypted
  return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
};

/**
 * Decrypt sensitive data
 */
export const decrypt = (encryptedText: string): string => {
  const parts = encryptedText.split(':');
  
  if (parts.length !== 3) {
    throw new Error('Invalid encrypted text format');
  }
  
  const [ivHex, authTagHex, encrypted] = parts;
  
  const iv = Buffer.from(ivHex, 'hex');
  const authTag = Buffer.from(authTagHex, 'hex');
  const key = Buffer.from(config.encryptionKey, 'hex');
  
  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(authTag);
  
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
};

/**
 * Hash a password with bcrypt-like security using PBKDF2
 * Note: In production, prefer using bcrypt package directly
 */
export const hashPassword = async (password: string): Promise<string> => {
  const salt = crypto.randomBytes(SALT_LENGTH);
  const iterations = 100000;
  const keyLength = 64;
  
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(password, salt, iterations, keyLength, 'sha512', (err, derivedKey) => {
      if (err) reject(err);
      resolve(`${salt.toString('hex')}:${iterations}:${derivedKey.toString('hex')}`);
    });
  });
};

/**
 * Verify a password against a hash
 */
export const verifyPassword = async (password: string, hash: string): Promise<boolean> => {
  const [saltHex, iterationsStr, keyHex] = hash.split(':');
  
  const salt = Buffer.from(saltHex, 'hex');
  const iterations = parseInt(iterationsStr, 10);
  const storedKey = Buffer.from(keyHex, 'hex');
  
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(password, salt, iterations, storedKey.length, 'sha512', (err, derivedKey) => {
      if (err) reject(err);
      resolve(crypto.timingSafeEqual(storedKey, derivedKey));
    });
  });
};

/**
 * Generate a secure random token
 */
export const generateToken = (length: number = 32): string => {
  return crypto.randomBytes(length).toString('hex');
};

/**
 * Generate a short code (e.g., for email verification)
 */
export const generateShortCode = (length: number = 6): string => {
  const chars = '0123456789';
  let code = '';
  const randomBytes = crypto.randomBytes(length);
  
  for (let i = 0; i < length; i++) {
    code += chars[randomBytes[i] % chars.length];
  }
  
  return code;
};

/**
 * Hash data with SHA-256 (for non-reversible hashing)
 */
export const sha256 = (data: string): string => {
  return crypto.createHash('sha256').update(data).digest('hex');
};

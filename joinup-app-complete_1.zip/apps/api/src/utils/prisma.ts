// =============================================================================
// PRISMA CLIENT SINGLETON
// =============================================================================

import { PrismaClient } from '@prisma/client';
import { config } from '../config/env';
import { logger } from './logger';

// Declare global type for Prisma client to prevent multiple instances in dev
declare global {
  var __prisma: PrismaClient | undefined;
}

// Create Prisma client with logging
const createPrismaClient = () => {
  return new PrismaClient({
    log: config.isDevelopment
      ? [
          { emit: 'event', level: 'query' },
          { emit: 'stdout', level: 'info' },
          { emit: 'stdout', level: 'warn' },
          { emit: 'stdout', level: 'error' },
        ]
      : [
          { emit: 'stdout', level: 'warn' },
          { emit: 'stdout', level: 'error' },
        ],
  });
};

// Use global variable in development to prevent multiple instances during hot reload
export const prisma = global.__prisma ?? createPrismaClient();

if (config.isDevelopment) {
  global.__prisma = prisma;
}

// Log slow queries in development
if (config.isDevelopment) {
  prisma.$on('query' as never, (e: any) => {
    if (e.duration > 100) {
      logger.warn(`Slow query (${e.duration}ms): ${e.query}`);
    }
  });
}

// Prisma middleware for soft deletes, auditing, etc.
prisma.$use(async (params, next) => {
  const startTime = Date.now();
  const result = await next(params);
  const duration = Date.now() - startTime;

  // Log slow operations
  if (duration > 1000) {
    logger.warn(`Slow DB operation (${duration}ms): ${params.model}.${params.action}`);
  }

  return result;
});

export default prisma;

// =============================================================================
// WEBSOCKET SETUP
// =============================================================================

import { Server, Socket } from 'socket.io';
import jwt from 'jsonwebtoken';
import { config } from './config/env';
import { prisma } from './utils/prisma';
import { logger } from './utils/logger';
import type { JwtPayload } from './middleware/auth';

// =============================================================================
// TYPES
// =============================================================================

interface AuthenticatedSocket extends Socket {
  userId: string;
  user: {
    id: string;
    name: string;
    username: string;
  };
}

// =============================================================================
// SETUP
// =============================================================================

export const setupWebSocket = (io: Server) => {
  // Authentication middleware
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.split(' ')[1];

      if (!token) {
        return next(new Error('Authentication required'));
      }

      const decoded = jwt.verify(token, config.jwt.accessSecret) as JwtPayload;

      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: {
          id: true,
          name: true,
          username: true,
          isActive: true,
        },
      });

      if (!user || !user.isActive) {
        return next(new Error('User not found or inactive'));
      }

      (socket as AuthenticatedSocket).userId = user.id;
      (socket as AuthenticatedSocket).user = user;
      
      next();
    } catch (error) {
      logger.error('WebSocket auth error:', error);
      next(new Error('Invalid token'));
    }
  });

  // Connection handler
  io.on('connection', (socket: Socket) => {
    const authSocket = socket as AuthenticatedSocket;
    logger.info(`User connected: ${authSocket.userId}`);

    // Join user's personal room
    socket.join(`user:${authSocket.userId}`);

    // ==========================================================================
    // CHAT EVENTS
    // ==========================================================================

    // Join a chat room
    socket.on('chat:join', async (chatId: string) => {
      try {
        // Verify user is member of chat
        const membership = await prisma.chatMember.findUnique({
          where: {
            chatId_userId: {
              chatId,
              userId: authSocket.userId,
            },
          },
        });

        if (membership && !membership.leftAt) {
          socket.join(`chat:${chatId}`);
          logger.debug(`User ${authSocket.userId} joined chat ${chatId}`);
        }
      } catch (error) {
        logger.error('Error joining chat:', error);
      }
    });

    // Leave a chat room
    socket.on('chat:leave', (chatId: string) => {
      socket.leave(`chat:${chatId}`);
      logger.debug(`User ${authSocket.userId} left chat ${chatId}`);
    });

    // Send typing indicator
    socket.on('chat:typing', (chatId: string) => {
      socket.to(`chat:${chatId}`).emit('chat:typing', {
        chatId,
        userId: authSocket.userId,
        user: authSocket.user,
      });
    });

    // Stop typing indicator
    socket.on('chat:stop-typing', (chatId: string) => {
      socket.to(`chat:${chatId}`).emit('chat:stop-typing', {
        chatId,
        userId: authSocket.userId,
      });
    });

    // ==========================================================================
    // EVENT EVENTS
    // ==========================================================================

    // Join an event room (for live updates)
    socket.on('event:join', async (eventId: string) => {
      socket.join(`event:${eventId}`);
      logger.debug(`User ${authSocket.userId} joined event ${eventId}`);
    });

    // Leave an event room
    socket.on('event:leave', (eventId: string) => {
      socket.leave(`event:${eventId}`);
    });

    // ==========================================================================
    // PRESENCE
    // ==========================================================================

    // Update online status
    const updatePresence = async (isOnline: boolean) => {
      // Broadcast to followers
      const followers = await prisma.follow.findMany({
        where: { followingId: authSocket.userId },
        select: { followerId: true },
      });

      followers.forEach((f) => {
        io.to(`user:${f.followerId}`).emit('presence:update', {
          userId: authSocket.userId,
          isOnline,
        });
      });
    };

    updatePresence(true);

    // ==========================================================================
    // DISCONNECT
    // ==========================================================================

    socket.on('disconnect', () => {
      logger.info(`User disconnected: ${authSocket.userId}`);
      updatePresence(false);
    });

    // Error handler
    socket.on('error', (error) => {
      logger.error('Socket error:', error);
    });
  });

  // ==========================================================================
  // HELPER FUNCTIONS (exported for use in controllers)
  // ==========================================================================

  return {
    /**
     * Send a message to a specific user
     */
    sendToUser: (userId: string, event: string, data: any) => {
      io.to(`user:${userId}`).emit(event, data);
    },

    /**
     * Send a message to all members of a chat
     */
    sendToChat: (chatId: string, event: string, data: any) => {
      io.to(`chat:${chatId}`).emit(event, data);
    },

    /**
     * Send a message to all users watching an event
     */
    sendToEvent: (eventId: string, event: string, data: any) => {
      io.to(`event:${eventId}`).emit(event, data);
    },

    /**
     * Broadcast to all connected users
     */
    broadcast: (event: string, data: any) => {
      io.emit(event, data);
    },
  };
};

export type WebSocketHelpers = ReturnType<typeof setupWebSocket>;

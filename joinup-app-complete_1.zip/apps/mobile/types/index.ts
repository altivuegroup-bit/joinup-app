// =============================================================================
// TYPESCRIPT TYPES
// =============================================================================

// =============================================================================
// USER
// =============================================================================

export interface User {
  id: string;
  email: string;
  name: string;
  username: string;
  bio?: string;
  avatarUrl?: string;
  coverImageUrl?: string;
  subscriptionTier: SubscriptionTier;
  emailVerified: boolean;
  createdAt: string;
  _count?: {
    hostedEvents: number;
    eventAttendances: number;
    followers: number;
    following: number;
  };
  socialConnections?: SocialConnection[];
  isFollowing?: boolean;
}

export type SubscriptionTier = 'FREE' | 'CONNECT' | 'CREATOR';

export interface SocialConnection {
  platform: SocialPlatform;
  platformUsername: string;
  isPublic: boolean;
}

export type SocialPlatform = 'INSTAGRAM' | 'TWITTER' | 'TIKTOK' | 'LINKEDIN' | 'YOUTUBE';

// =============================================================================
// AUTH
// =============================================================================

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  password: string;
  name: string;
  username: string;
}

export interface AuthResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
}

// =============================================================================
// EVENTS
// =============================================================================

export interface Event {
  id: string;
  hostId: string;
  host: EventHost;
  title: string;
  description: string;
  slug: string;
  imageUrl?: string;
  category: EventCategory;
  tags: string[];
  isOnline: boolean;
  locationName?: string;
  locationAddress?: string;
  locationLat?: number;
  locationLng?: number;
  onlineUrl?: string;
  startTime: string;
  endTime: string;
  timezone: string;
  capacity: number;
  status: EventStatus;
  attendeeCount: number;
  viewCount: number;
  avgRating?: number;
  reviewCount: number;
  createdAt: string;
  ticketTypes?: TicketType[];
  isAttending?: boolean;
  attendeeStatus?: AttendeeStatus;
}

export interface EventHost {
  id: string;
  name: string;
  username: string;
  avatarUrl?: string;
  isFollowing?: boolean;
}

export type EventCategory =
  | 'WELLNESS'
  | 'MUSIC'
  | 'TECH'
  | 'FOOD'
  | 'ART'
  | 'SPORTS'
  | 'SOCIAL'
  | 'BUSINESS'
  | 'EDUCATION'
  | 'OTHER';

export type EventStatus = 'DRAFT' | 'PUBLISHED' | 'CANCELLED' | 'COMPLETED';

export type AttendeeStatus = 'GOING' | 'MAYBE' | 'NOT_GOING' | 'WAITLIST';

export interface TicketType {
  id: string;
  name: string;
  description?: string;
  priceCents: number;
  quantity: number;
  quantitySold: number;
  maxPerPerson: number;
  isActive: boolean;
}

export interface EventFilters {
  category?: EventCategory;
  search?: string;
  startDate?: string;
  endDate?: string;
  isOnline?: boolean;
  isFree?: boolean;
  lat?: number;
  lng?: number;
  radius?: number;
}

export interface CreateEventRequest {
  title: string;
  description: string;
  category: EventCategory;
  tags?: string[];
  isOnline: boolean;
  locationName?: string;
  locationAddress?: string;
  locationLat?: number;
  locationLng?: number;
  onlineUrl?: string;
  startTime: string;
  endTime: string;
  capacity: number;
  imageUrl?: string;
  ticketTypes?: CreateTicketTypeRequest[];
}

export interface CreateTicketTypeRequest {
  name: string;
  description?: string;
  priceCents: number;
  quantity: number;
  maxPerPerson?: number;
}

// =============================================================================
// REVIEWS
// =============================================================================

export interface Review {
  id: string;
  eventId: string;
  userId: string;
  user: {
    id: string;
    name: string;
    username: string;
    avatarUrl?: string;
  };
  rating: number;
  title?: string;
  content?: string;
  createdAt: string;
}

// =============================================================================
// CHAT
// =============================================================================

export interface Chat {
  id: string;
  type: ChatType;
  name?: string;
  imageUrl?: string;
  eventId?: string;
  members: ChatMember[];
  lastMessage?: Message;
  unreadCount: number;
  updatedAt: string;
}

export type ChatType = 'DIRECT' | 'GROUP' | 'EVENT';

export interface ChatMember {
  userId: string;
  user: {
    id: string;
    name: string;
    username: string;
    avatarUrl?: string;
  };
  role: ChatRole;
  isMuted: boolean;
  lastReadAt?: string;
}

export type ChatRole = 'ADMIN' | 'MODERATOR' | 'MEMBER';

export interface Message {
  id: string;
  chatId: string;
  senderId: string;
  sender: {
    id: string;
    name: string;
    username: string;
    avatarUrl?: string;
  };
  content: string;
  type: MessageType;
  attachmentUrl?: string;
  createdAt: string;
  editedAt?: string;
}

export type MessageType = 'TEXT' | 'IMAGE' | 'EVENT_SHARE' | 'SYSTEM';

// =============================================================================
// NOTIFICATIONS
// =============================================================================

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  body: string;
  data?: Record<string, any>;
  isRead: boolean;
  createdAt: string;
}

export type NotificationType =
  | 'EVENT_REMINDER'
  | 'EVENT_UPDATE'
  | 'EVENT_CANCELLED'
  | 'NEW_FOLLOWER'
  | 'NEW_MESSAGE'
  | 'NEW_REVIEW'
  | 'TICKET_PURCHASED'
  | 'PAYOUT_COMPLETED'
  | 'SYSTEM';

// =============================================================================
// API RESPONSES
// =============================================================================

export interface ApiResponse<T> {
  success: boolean;
  data: T;
}

export interface ApiError {
  success: false;
  error: {
    message: string;
    code?: string;
    errors?: Record<string, string[]>;
  };
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  hasMore: boolean;
}

// =============================================================================
// NAVIGATION
// =============================================================================

export type RootStackParamList = {
  '(tabs)': undefined;
  'auth/login': undefined;
  'auth/register': undefined;
  'auth/forgot-password': undefined;
  'event/[id]': { id: string };
  'profile/[username]': { username: string };
  'profile/edit': undefined;
  'profile/qr': undefined;
  'chat/[id]': { id: string };
  'settings': undefined;
  'settings/account': undefined;
  'settings/notifications': undefined;
  'settings/subscription': undefined;
};

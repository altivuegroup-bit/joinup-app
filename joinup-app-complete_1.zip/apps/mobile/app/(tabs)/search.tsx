// =============================================================================
// SEARCH SCREEN
// =============================================================================

import { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  FlatList,
  TouchableOpacity,
  useColorScheme,
  ActivityIndicator,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { format } from 'date-fns';
import { useDebouncedValue } from '@/hooks/useDebounce';
import { Colors, EventCategories, Spacing, BorderRadius, Typography } from '@/constants';
import { apiClient } from '@/lib/api';
import type { Event, PaginatedResponse } from '@/types';

export default function SearchScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const colors = isDark ? Colors.dark : Colors.light;

  const [searchQuery, setSearchQuery] = useState('');
  const debouncedQuery = useDebouncedValue(searchQuery, 300);

  // Fetch search results
  const { data, isLoading, isFetching } = useQuery({
    queryKey: ['search', debouncedQuery],
    queryFn: () =>
      apiClient.get<PaginatedResponse<Event>>('/events', {
        params: {
          search: debouncedQuery,
          status: 'PUBLISHED',
          pageSize: 20,
        },
      }),
    enabled: debouncedQuery.length >= 2,
  });

  const clearSearch = useCallback(() => {
    setSearchQuery('');
  }, []);

  const renderSearchResult = ({ item }: { item: Event }) => {
    const categoryInfo = EventCategories.find((c) => c.id === item.category);
    const formattedDate = format(new Date(item.startTime), 'MMM d · h:mm a');

    return (
      <TouchableOpacity
        style={[styles.resultItem, { backgroundColor: colors.card }]}
        onPress={() => router.push(`/event/${item.id}`)}
        activeOpacity={0.7}
      >
        <Image
          source={{ uri: item.imageUrl || 'https://via.placeholder.com/80' }}
          style={styles.resultImage}
          contentFit="cover"
        />
        <View style={styles.resultContent}>
          <Text style={[styles.resultTitle, { color: colors.text }]} numberOfLines={2}>
            {item.title}
          </Text>
          <Text style={[styles.resultMeta, { color: colors.textSecondary }]}>
            {formattedDate}
          </Text>
          <View style={styles.resultFooter}>
            <View style={[styles.categoryTag, { backgroundColor: categoryInfo?.color + '20' }]}>
              <Text style={[styles.categoryTagText, { color: categoryInfo?.color }]}>
                {categoryInfo?.label}
              </Text>
            </View>
            <Text style={[styles.attendeeText, { color: colors.textTertiary }]}>
              {item.attendeeCount} going
            </Text>
          </View>
        </View>
        <Ionicons name="chevron-forward" size={20} color={colors.textTertiary} />
      </TouchableOpacity>
    );
  };

  const renderRecentSearch = ({ item }: { item: string }) => (
    <TouchableOpacity
      style={styles.recentItem}
      onPress={() => setSearchQuery(item)}
      activeOpacity={0.7}
    >
      <Ionicons name="time-outline" size={20} color={colors.textSecondary} />
      <Text style={[styles.recentText, { color: colors.text }]}>{item}</Text>
    </TouchableOpacity>
  );

  const renderPopularCategory = ({ item }: { item: typeof EventCategories[number] }) => (
    <TouchableOpacity
      style={[styles.popularCategory, { backgroundColor: colors.backgroundSecondary }]}
      onPress={() => {
        setSearchQuery(item.label);
      }}
      activeOpacity={0.7}
    >
      <View style={[styles.categoryIcon, { backgroundColor: item.color + '20' }]}>
        <Ionicons name={item.icon as any} size={24} color={item.color} />
      </View>
      <Text style={[styles.categoryName, { color: colors.text }]}>{item.label}</Text>
    </TouchableOpacity>
  );

  const EmptySearch = () => (
    <View style={styles.emptySearch}>
      {/* Popular Categories */}
      <Text style={[styles.sectionTitle, { color: colors.text }]}>Popular Categories</Text>
      <FlatList
        data={EventCategories.slice(0, 6)}
        renderItem={renderPopularCategory}
        keyExtractor={(item) => item.id}
        numColumns={3}
        scrollEnabled={false}
        contentContainerStyle={styles.categoriesGrid}
      />

      {/* Recent Searches */}
      <Text style={[styles.sectionTitle, { color: colors.text, marginTop: Spacing.xl }]}>
        Recent Searches
      </Text>
      <FlatList
        data={['Yoga', 'Music Night', 'Tech Meetup']}
        renderItem={renderRecentSearch}
        keyExtractor={(item) => item}
        scrollEnabled={false}
      />
    </View>
  );

  const NoResults = () => (
    <View style={styles.noResults}>
      <Ionicons name="search-outline" size={64} color={colors.textTertiary} />
      <Text style={[styles.noResultsTitle, { color: colors.text }]}>No results found</Text>
      <Text style={[styles.noResultsSubtitle, { color: colors.textSecondary }]}>
        Try searching for something else
      </Text>
    </View>
  );

  const showResults = debouncedQuery.length >= 2;
  const hasResults = data?.items && data.items.length > 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <View style={[styles.searchBar, { backgroundColor: colors.backgroundSecondary }]}>
          <Ionicons name="search" size={20} color={colors.textSecondary} />
          <TextInput
            style={[styles.searchInput, { color: colors.text }]}
            placeholder="Search events, hosts, locations..."
            placeholderTextColor={colors.textTertiary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="search"
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={clearSearch}>
              <Ionicons name="close-circle" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
          )}
          {isFetching && <ActivityIndicator size="small" color={colors.primary} />}
        </View>
      </View>

      {/* Content */}
      {!showResults ? (
        <EmptySearch />
      ) : hasResults ? (
        <FlatList
          data={data?.items}
          renderItem={renderSearchResult}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.resultsList}
          showsVerticalScrollIndicator={false}
        />
      ) : !isLoading ? (
        <NoResults />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  searchContainer: {
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.lg,
    gap: Spacing.sm,
  },
  searchInput: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.base,
  },
  emptySearch: {
    padding: Spacing.base,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.lg,
    marginBottom: Spacing.md,
  },
  categoriesGrid: {
    gap: Spacing.sm,
  },
  popularCategory: {
    flex: 1,
    alignItems: 'center',
    padding: Spacing.md,
    marginHorizontal: Spacing.xs,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.sm,
  },
  categoryIcon: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.sm,
  },
  categoryName: {
    fontFamily: 'Inter-Medium',
    fontSize: Typography.fontSize.sm,
    textAlign: 'center',
  },
  recentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.md,
    gap: Spacing.md,
  },
  recentText: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.base,
  },
  resultsList: {
    padding: Spacing.base,
  },
  resultItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.sm,
    gap: Spacing.md,
  },
  resultImage: {
    width: 70,
    height: 70,
    borderRadius: BorderRadius.md,
  },
  resultContent: {
    flex: 1,
  },
  resultTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.base,
    marginBottom: Spacing.xs,
  },
  resultMeta: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.sm,
    marginBottom: Spacing.sm,
  },
  resultFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  categoryTag: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: BorderRadius.sm,
  },
  categoryTagText: {
    fontFamily: 'Inter-Medium',
    fontSize: Typography.fontSize.xs,
  },
  attendeeText: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.xs,
  },
  noResults: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.xl,
  },
  noResultsTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.lg,
    marginTop: Spacing.base,
  },
  noResultsSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.sm,
    marginTop: Spacing.xs,
    textAlign: 'center',
  },
});

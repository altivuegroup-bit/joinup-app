// =============================================================================
// CREATE EVENT SCREEN
// =============================================================================

import { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  useColorScheme,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useMutation } from '@tanstack/react-query';
import { Colors, EventCategories, Spacing, BorderRadius, Typography, Limits } from '@/constants';
import { apiClient } from '@/lib/api';
import { useAuthStore } from '@/store/auth';
import type { Event, EventCategory, CreateEventRequest } from '@/types';

export default function CreateEventScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const colors = isDark ? Colors.dark : Colors.light;

  const { user, isAuthenticated } = useAuthStore();

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<EventCategory | null>(null);
  const [isOnline, setIsOnline] = useState(false);
  const [locationName, setLocationName] = useState('');
  const [locationAddress, setLocationAddress] = useState('');
  const [onlineUrl, setOnlineUrl] = useState('');
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date(Date.now() + 2 * 60 * 60 * 1000));
  const [capacity, setCapacity] = useState('50');
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showEndPicker, setShowEndPicker] = useState(false);

  // Mutation
  const createMutation = useMutation({
    mutationFn: (data: CreateEventRequest) => apiClient.post<Event>('/events', data),
    onSuccess: (event) => {
      Alert.alert('Success', 'Your event has been created!', [
        { text: 'View Event', onPress: () => router.replace(`/event/${event.id}`) },
      ]);
    },
    onError: (error: any) => {
      Alert.alert('Error', error.response?.data?.error?.message || 'Failed to create event');
    },
  });

  // Check subscription
  if (!isAuthenticated || !user) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <Ionicons name="add-circle-outline" size={64} color={colors.textTertiary} />
        <Text style={[styles.emptyTitle, { color: colors.text }]}>Sign in to create events</Text>
        <TouchableOpacity
          style={[styles.signInButton, { backgroundColor: colors.primary }]}
          onPress={() => router.push('/auth/login')}
        >
          <Text style={styles.signInButtonText}>Sign In</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (user.subscriptionTier !== 'CREATOR') {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <Ionicons name="star" size={64} color={colors.primary} />
        <Text style={[styles.emptyTitle, { color: colors.text }]}>Creator Plan Required</Text>
        <Text style={[styles.emptySubtitle, { color: colors.textSecondary }]}>
          Upgrade to Creator to host unlimited events and sell tickets
        </Text>
        <TouchableOpacity
          style={[styles.upgradeButton, { backgroundColor: colors.primary }]}
          onPress={() => router.push('/settings/subscription')}
        >
          <Text style={styles.upgradeButtonText}>Upgrade to Creator - $6.99/mo</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const handleSubmit = () => {
    if (!title.trim()) {
      Alert.alert('Error', 'Please enter an event title');
      return;
    }
    if (!category) {
      Alert.alert('Error', 'Please select a category');
      return;
    }
    if (!description.trim()) {
      Alert.alert('Error', 'Please enter a description');
      return;
    }
    if (!isOnline && !locationName.trim()) {
      Alert.alert('Error', 'Please enter a location');
      return;
    }
    if (isOnline && !onlineUrl.trim()) {
      Alert.alert('Error', 'Please enter an online event URL');
      return;
    }

    createMutation.mutate({
      title: title.trim(),
      description: description.trim(),
      category,
      isOnline,
      locationName: isOnline ? undefined : locationName.trim(),
      locationAddress: isOnline ? undefined : locationAddress.trim(),
      onlineUrl: isOnline ? onlineUrl.trim() : undefined,
      startTime: startDate.toISOString(),
      endTime: endDate.toISOString(),
      capacity: parseInt(capacity, 10) || 50,
    });
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <ScrollView
        style={[styles.container, { backgroundColor: colors.background }]}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Title */}
        <View style={styles.inputGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Event Title *</Text>
          <TextInput
            style={[styles.input, { backgroundColor: colors.backgroundSecondary, color: colors.text }]}
            placeholder="Give your event a catchy title"
            placeholderTextColor={colors.textTertiary}
            value={title}
            onChangeText={setTitle}
            maxLength={Limits.EVENT_TITLE_MAX_LENGTH}
          />
          <Text style={[styles.charCount, { color: colors.textTertiary }]}>
            {title.length}/{Limits.EVENT_TITLE_MAX_LENGTH}
          </Text>
        </View>

        {/* Category */}
        <View style={styles.inputGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Category *</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.categoryRow}>
              {EventCategories.map((cat) => (
                <TouchableOpacity
                  key={cat.id}
                  style={[
                    styles.categoryChip,
                    {
                      backgroundColor: category === cat.id ? cat.color : colors.backgroundSecondary,
                      borderColor: category === cat.id ? cat.color : colors.border,
                    },
                  ]}
                  onPress={() => setCategory(cat.id as EventCategory)}
                >
                  <Ionicons
                    name={cat.icon as any}
                    size={16}
                    color={category === cat.id ? '#fff' : cat.color}
                  />
                  <Text
                    style={[
                      styles.categoryLabel,
                      { color: category === cat.id ? '#fff' : colors.text },
                    ]}
                  >
                    {cat.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Description */}
        <View style={styles.inputGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Description *</Text>
          <TextInput
            style={[
              styles.input,
              styles.textArea,
              { backgroundColor: colors.backgroundSecondary, color: colors.text },
            ]}
            placeholder="Tell people what your event is about..."
            placeholderTextColor={colors.textTertiary}
            value={description}
            onChangeText={setDescription}
            multiline
            numberOfLines={4}
            maxLength={Limits.EVENT_DESCRIPTION_MAX_LENGTH}
            textAlignVertical="top"
          />
        </View>

        {/* Online Toggle */}
        <View style={styles.inputGroup}>
          <TouchableOpacity
            style={[styles.toggleRow, { backgroundColor: colors.backgroundSecondary }]}
            onPress={() => setIsOnline(!isOnline)}
          >
            <View style={styles.toggleLeft}>
              <Ionicons name="videocam" size={22} color={colors.primary} />
              <Text style={[styles.toggleLabel, { color: colors.text }]}>Online Event</Text>
            </View>
            <View
              style={[
                styles.toggle,
                { backgroundColor: isOnline ? colors.primary : colors.border },
              ]}
            >
              <View
                style={[
                  styles.toggleThumb,
                  { transform: [{ translateX: isOnline ? 20 : 0 }] },
                ]}
              />
            </View>
          </TouchableOpacity>
        </View>

        {/* Location / URL */}
        {isOnline ? (
          <View style={styles.inputGroup}>
            <Text style={[styles.label, { color: colors.text }]}>Event URL *</Text>
            <TextInput
              style={[styles.input, { backgroundColor: colors.backgroundSecondary, color: colors.text }]}
              placeholder="https://zoom.us/j/..."
              placeholderTextColor={colors.textTertiary}
              value={onlineUrl}
              onChangeText={setOnlineUrl}
              keyboardType="url"
              autoCapitalize="none"
            />
          </View>
        ) : (
          <>
            <View style={styles.inputGroup}>
              <Text style={[styles.label, { color: colors.text }]}>Venue Name *</Text>
              <TextInput
                style={[styles.input, { backgroundColor: colors.backgroundSecondary, color: colors.text }]}
                placeholder="e.g. Central Park, The Blue Note"
                placeholderTextColor={colors.textTertiary}
                value={locationName}
                onChangeText={setLocationName}
              />
            </View>
            <View style={styles.inputGroup}>
              <Text style={[styles.label, { color: colors.text }]}>Address</Text>
              <TextInput
                style={[styles.input, { backgroundColor: colors.backgroundSecondary, color: colors.text }]}
                placeholder="Full street address"
                placeholderTextColor={colors.textTertiary}
                value={locationAddress}
                onChangeText={setLocationAddress}
              />
            </View>
          </>
        )}

        {/* Date & Time */}
        <View style={styles.inputGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Date & Time *</Text>
          <View style={styles.dateTimeRow}>
            <TouchableOpacity
              style={[styles.dateButton, { backgroundColor: colors.backgroundSecondary }]}
              onPress={() => setShowStartPicker(true)}
            >
              <Ionicons name="calendar-outline" size={20} color={colors.textSecondary} />
              <Text style={[styles.dateText, { color: colors.text }]}>
                {startDate.toLocaleDateString()} {startDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </Text>
            </TouchableOpacity>
            <Text style={[styles.toText, { color: colors.textSecondary }]}>to</Text>
            <TouchableOpacity
              style={[styles.dateButton, { backgroundColor: colors.backgroundSecondary }]}
              onPress={() => setShowEndPicker(true)}
            >
              <Text style={[styles.dateText, { color: colors.text }]}>
                {endDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Capacity */}
        <View style={styles.inputGroup}>
          <Text style={[styles.label, { color: colors.text }]}>Capacity</Text>
          <TextInput
            style={[styles.input, { backgroundColor: colors.backgroundSecondary, color: colors.text }]}
            placeholder="50"
            placeholderTextColor={colors.textTertiary}
            value={capacity}
            onChangeText={setCapacity}
            keyboardType="number-pad"
          />
        </View>

        {/* Submit Button */}
        <TouchableOpacity
          style={[
            styles.submitButton,
            { backgroundColor: colors.primary },
            createMutation.isPending && styles.submitButtonDisabled,
          ]}
          onPress={handleSubmit}
          disabled={createMutation.isPending}
        >
          <Text style={styles.submitButtonText}>
            {createMutation.isPending ? 'Creating...' : 'Create Event'}
          </Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Date Pickers */}
      {showStartPicker && (
        <DateTimePicker
          value={startDate}
          mode="datetime"
          onChange={(event, date) => {
            setShowStartPicker(false);
            if (date) setStartDate(date);
          }}
        />
      )}
      {showEndPicker && (
        <DateTimePicker
          value={endDate}
          mode="time"
          onChange={(event, date) => {
            setShowEndPicker(false);
            if (date) setEndDate(date);
          }}
        />
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { alignItems: 'center', justifyContent: 'center', padding: Spacing.xl },
  scrollContent: { padding: Spacing.base, paddingBottom: Spacing['4xl'] },
  emptyTitle: { fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.lg, marginTop: Spacing.base, textAlign: 'center' },
  emptySubtitle: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.sm, marginTop: Spacing.sm, textAlign: 'center', lineHeight: 20, paddingHorizontal: Spacing.xl },
  signInButton: { paddingHorizontal: Spacing['2xl'], paddingVertical: Spacing.md, borderRadius: BorderRadius.lg, marginTop: Spacing.xl },
  signInButtonText: { color: '#fff', fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.base },
  upgradeButton: { paddingHorizontal: Spacing.xl, paddingVertical: Spacing.md, borderRadius: BorderRadius.lg, marginTop: Spacing.xl },
  upgradeButtonText: { color: '#fff', fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.base },
  inputGroup: { marginBottom: Spacing.lg },
  label: { fontFamily: 'Inter-Medium', fontSize: Typography.fontSize.sm, marginBottom: Spacing.sm },
  input: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.md, borderRadius: BorderRadius.lg, fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.base },
  textArea: { minHeight: 100, paddingTop: Spacing.md },
  charCount: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.xs, textAlign: 'right', marginTop: Spacing.xs },
  categoryRow: { flexDirection: 'row', gap: Spacing.sm },
  categoryChip: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: BorderRadius.full, borderWidth: 1, gap: Spacing.xs },
  categoryLabel: { fontFamily: 'Inter-Medium', fontSize: Typography.fontSize.sm },
  toggleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: Spacing.md, borderRadius: BorderRadius.lg },
  toggleLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  toggleLabel: { fontFamily: 'Inter-Medium', fontSize: Typography.fontSize.base },
  toggle: { width: 50, height: 30, borderRadius: 15, justifyContent: 'center', padding: 2 },
  toggleThumb: { width: 26, height: 26, borderRadius: 13, backgroundColor: '#fff' },
  dateTimeRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  dateButton: { flex: 1, flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: Spacing.md, borderRadius: BorderRadius.lg, gap: Spacing.sm },
  dateText: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.sm },
  toText: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.sm },
  submitButton: { paddingVertical: Spacing.md, borderRadius: BorderRadius.lg, alignItems: 'center', marginTop: Spacing.xl },
  submitButtonDisabled: { opacity: 0.6 },
  submitButtonText: { color: '#fff', fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.base },
});

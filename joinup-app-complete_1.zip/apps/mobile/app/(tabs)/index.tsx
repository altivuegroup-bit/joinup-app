// =============================================================================
// HOME / DISCOVER SCREEN
// =============================================================================

import { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  TouchableOpacity,
  useColorScheme,
  Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { format } from 'date-fns';
import { Colors, EventCategories, Spacing, BorderRadius, Typography } from '@/constants';
import { apiClient } from '@/lib/api';
import type { Event, PaginatedResponse } from '@/types';

const { width } = Dimensions.get('window');
const CARD_WIDTH = width - Spacing.base * 2;

export default function DiscoverScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const colors = isDark ? Colors.dark : Colors.light;

  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  // Fetch events
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['events', selectedCategory],
    queryFn: () =>
      apiClient.get<PaginatedResponse<Event>>('/events', {
        params: {
          category: selectedCategory,
          status: 'PUBLISHED',
          pageSize: 20,
        },
      }),
  });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  const renderCategoryItem = ({ item }: { item: typeof EventCategories[number] }) => {
    const isSelected = selectedCategory === item.id;
    return (
      <TouchableOpacity
        style={[
          styles.categoryChip,
          {
            backgroundColor: isSelected ? colors.primary : colors.backgroundSecondary,
            borderColor: isSelected ? colors.primary : colors.border,
          },
        ]}
        onPress={() => setSelectedCategory(isSelected ? null : item.id)}
        activeOpacity={0.7}
      >
        <Ionicons
          name={item.icon as any}
          size={16}
          color={isSelected ? '#fff' : item.color}
        />
        <Text
          style={[
            styles.categoryLabel,
            { color: isSelected ? '#fff' : colors.text },
          ]}
        >
          {item.label}
        </Text>
      </TouchableOpacity>
    );
  };

  const renderEventCard = ({ item }: { item: Event }) => {
    const categoryInfo = EventCategories.find((c) => c.id === item.category);
    const formattedDate = format(new Date(item.startTime), 'EEE, MMM d · h:mm a');
    const isFree = !item.ticketTypes?.some((t) => t.priceCents > 0);

    return (
      <TouchableOpacity
        style={[styles.eventCard, { backgroundColor: colors.card }]}
        onPress={() => router.push(`/event/${item.id}`)}
        activeOpacity={0.9}
      >
        {/* Image */}
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: item.imageUrl || 'https://via.placeholder.com/400x200' }}
            style={styles.eventImage}
            contentFit="cover"
            transition={200}
          />
          {/* Category badge */}
          <View style={[styles.categoryBadge, { backgroundColor: categoryInfo?.color }]}>
            <Text style={styles.categoryBadgeText}>{categoryInfo?.label}</Text>
          </View>
          {/* Price badge */}
          {isFree && (
            <View style={[styles.priceBadge, { backgroundColor: colors.success }]}>
              <Text style={styles.priceBadgeText}>Free</Text>
            </View>
          )}
        </View>

        {/* Content */}
        <View style={styles.eventContent}>
          <Text style={[styles.eventTitle, { color: colors.text }]} numberOfLines={2}>
            {item.title}
          </Text>

          <View style={styles.eventMeta}>
            <View style={styles.metaRow}>
              <Ionicons name="calendar-outline" size={14} color={colors.textSecondary} />
              <Text style={[styles.metaText, { color: colors.textSecondary }]}>
                {formattedDate}
              </Text>
            </View>

            <View style={styles.metaRow}>
              <Ionicons
                name={item.isOnline ? 'videocam-outline' : 'location-outline'}
                size={14}
                color={colors.textSecondary}
              />
              <Text style={[styles.metaText, { color: colors.textSecondary }]} numberOfLines={1}>
                {item.isOnline ? 'Online Event' : item.locationName}
              </Text>
            </View>
          </View>

          {/* Host & Attendees */}
          <View style={styles.eventFooter}>
            <View style={styles.hostInfo}>
              <Image
                source={{ uri: item.host.avatarUrl || 'https://via.placeholder.com/40' }}
                style={styles.hostAvatar}
              />
              <Text style={[styles.hostName, { color: colors.textSecondary }]}>
                {item.host.name}
              </Text>
            </View>

            <View style={styles.attendeeInfo}>
              <Ionicons name="people" size={14} color={colors.textSecondary} />
              <Text style={[styles.attendeeCount, { color: colors.textSecondary }]}>
                {item.attendeeCount} going
              </Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const ListHeader = () => (
    <View style={styles.header}>
      {/* Categories */}
      <FlatList
        data={EventCategories}
        renderItem={renderCategoryItem}
        keyExtractor={(item) => item.id}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.categoriesList}
      />
    </View>
  );

  const ListEmpty = () => (
    <View style={styles.emptyState}>
      <Ionicons name="calendar-outline" size={64} color={colors.textTertiary} />
      <Text style={[styles.emptyTitle, { color: colors.text }]}>No events found</Text>
      <Text style={[styles.emptySubtitle, { color: colors.textSecondary }]}>
        {selectedCategory
          ? 'Try selecting a different category'
          : 'Check back later for new events'}
      </Text>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={data?.items || []}
        renderItem={renderEventCard}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={ListHeader}
        ListEmptyComponent={!isLoading ? ListEmpty : null}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingBottom: Spacing.base,
  },
  categoriesList: {
    paddingHorizontal: Spacing.base,
    gap: Spacing.sm,
  },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    gap: Spacing.xs,
  },
  categoryLabel: {
    fontFamily: 'Inter-Medium',
    fontSize: Typography.fontSize.sm,
  },
  listContent: {
    paddingBottom: Spacing['2xl'],
  },
  eventCard: {
    marginHorizontal: Spacing.base,
    marginBottom: Spacing.base,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  imageContainer: {
    position: 'relative',
  },
  eventImage: {
    width: '100%',
    height: 180,
  },
  categoryBadge: {
    position: 'absolute',
    top: Spacing.sm,
    left: Spacing.sm,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
  },
  categoryBadgeText: {
    color: '#fff',
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.xs,
  },
  priceBadge: {
    position: 'absolute',
    top: Spacing.sm,
    right: Spacing.sm,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
  },
  priceBadgeText: {
    color: '#fff',
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.xs,
  },
  eventContent: {
    padding: Spacing.base,
  },
  eventTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.lg,
    marginBottom: Spacing.sm,
  },
  eventMeta: {
    gap: Spacing.xs,
    marginBottom: Spacing.md,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  metaText: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.sm,
    flex: 1,
  },
  eventFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  hostInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  hostAvatar: {
    width: 24,
    height: 24,
    borderRadius: 12,
  },
  hostName: {
    fontFamily: 'Inter-Medium',
    fontSize: Typography.fontSize.sm,
  },
  attendeeInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  attendeeCount: {
    fontFamily: 'Inter-Medium',
    fontSize: Typography.fontSize.sm,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing['4xl'],
  },
  emptyTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.lg,
    marginTop: Spacing.base,
  },
  emptySubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.sm,
    marginTop: Spacing.xs,
    textAlign: 'center',
  },
});

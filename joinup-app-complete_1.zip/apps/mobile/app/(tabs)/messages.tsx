// =============================================================================
// MESSAGES TAB SCREEN
// =============================================================================

import { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  useColorScheme,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { formatDistanceToNow } from 'date-fns';
import { Colors, Spacing, BorderRadius, Typography } from '@/constants';
import { apiClient } from '@/lib/api';
import { useAuthStore } from '@/store/auth';
import type { Chat } from '@/types';

export default function MessagesScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const colors = isDark ? Colors.dark : Colors.light;

  const { user, isAuthenticated } = useAuthStore();
  const [refreshing, setRefreshing] = useState(false);

  const { data: chats, isLoading, refetch } = useQuery({
    queryKey: ['chats'],
    queryFn: () => apiClient.get<Chat[]>('/chats'),
    enabled: isAuthenticated,
  });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  if (!isAuthenticated) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <Ionicons name="chatbubbles-outline" size={64} color={colors.textTertiary} />
        <Text style={[styles.emptyTitle, { color: colors.text }]}>Sign in to message</Text>
        <Text style={[styles.emptySubtitle, { color: colors.textSecondary }]}>
          Connect with event hosts and other attendees
        </Text>
        <TouchableOpacity
          style={[styles.signInButton, { backgroundColor: colors.primary }]}
          onPress={() => router.push('/auth/login')}
        >
          <Text style={styles.signInButtonText}>Sign In</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const getChatName = (chat: Chat) => {
    if (chat.name) return chat.name;
    if (chat.type === 'DIRECT') {
      const otherMember = chat.members.find((m) => m.userId !== user?.id);
      return otherMember?.user.name || 'Unknown';
    }
    return 'Group Chat';
  };

  const getChatImage = (chat: Chat) => {
    if (chat.imageUrl) return chat.imageUrl;
    if (chat.type === 'DIRECT') {
      const otherMember = chat.members.find((m) => m.userId !== user?.id);
      return otherMember?.user.avatarUrl || 'https://via.placeholder.com/50';
    }
    return 'https://via.placeholder.com/50';
  };

  const renderChatItem = ({ item }: { item: Chat }) => {
    const hasUnread = item.unreadCount > 0;
    const timeAgo = item.lastMessage
      ? formatDistanceToNow(new Date(item.lastMessage.createdAt), { addSuffix: true })
      : '';

    return (
      <TouchableOpacity
        style={[styles.chatItem, { backgroundColor: colors.card }]}
        onPress={() => router.push(`/chat/${item.id}`)}
        activeOpacity={0.7}
      >
        <View style={styles.avatarContainer}>
          <Image source={{ uri: getChatImage(item) }} style={styles.avatar} />
          {chat.type === 'EVENT' && (
            <View style={[styles.chatTypeBadge, { backgroundColor: colors.primary }]}>
              <Ionicons name="calendar" size={10} color="#fff" />
            </View>
          )}
        </View>

        <View style={styles.chatContent}>
          <View style={styles.chatHeader}>
            <Text
              style={[
                styles.chatName,
                { color: colors.text },
                hasUnread && styles.chatNameUnread,
              ]}
              numberOfLines={1}
            >
              {getChatName(item)}
            </Text>
            <Text style={[styles.chatTime, { color: colors.textTertiary }]}>{timeAgo}</Text>
          </View>

          <View style={styles.chatPreview}>
            <Text
              style={[
                styles.chatMessage,
                { color: hasUnread ? colors.text : colors.textSecondary },
                hasUnread && styles.chatMessageUnread,
              ]}
              numberOfLines={1}
            >
              {item.lastMessage?.content || 'No messages yet'}
            </Text>
            {hasUnread && (
              <View style={[styles.unreadBadge, { backgroundColor: colors.primary }]}>
                <Text style={styles.unreadCount}>
                  {item.unreadCount > 99 ? '99+' : item.unreadCount}
                </Text>
              </View>
            )}
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const ListEmpty = () => (
    <View style={styles.emptyState}>
      <Ionicons name="chatbubbles-outline" size={64} color={colors.textTertiary} />
      <Text style={[styles.emptyTitle, { color: colors.text }]}>No messages yet</Text>
      <Text style={[styles.emptySubtitle, { color: colors.textSecondary }]}>
        Start a conversation by joining an event or following someone
      </Text>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={chats || []}
        renderItem={renderChatItem}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={!isLoading ? ListEmpty : null}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={colors.primary}
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  centered: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.xl,
  },
  listContent: {
    flexGrow: 1,
  },
  chatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.base,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(0,0,0,0.1)',
  },
  avatarContainer: {
    position: 'relative',
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
  },
  chatTypeBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  chatContent: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.xs,
  },
  chatName: {
    fontFamily: 'Inter-Medium',
    fontSize: Typography.fontSize.base,
    flex: 1,
    marginRight: Spacing.sm,
  },
  chatNameUnread: {
    fontFamily: 'Inter-SemiBold',
  },
  chatTime: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.xs,
  },
  chatPreview: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  chatMessage: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.sm,
    flex: 1,
  },
  chatMessageUnread: {
    fontFamily: 'Inter-Medium',
  },
  unreadBadge: {
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 6,
    marginLeft: Spacing.sm,
  },
  unreadCount: {
    color: '#fff',
    fontFamily: 'Inter-Bold',
    fontSize: 11,
  },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.xl,
  },
  emptyTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.lg,
    marginTop: Spacing.base,
    textAlign: 'center',
  },
  emptySubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.sm,
    marginTop: Spacing.sm,
    textAlign: 'center',
    lineHeight: 20,
  },
  signInButton: {
    paddingHorizontal: Spacing['2xl'],
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.lg,
    marginTop: Spacing.xl,
  },
  signInButtonText: {
    color: '#fff',
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.base,
  },
});

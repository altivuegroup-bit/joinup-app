// =============================================================================
// PROFILE TAB SCREEN
// =============================================================================

import { View, Text, StyleSheet, ScrollView, TouchableOpacity, useColorScheme } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useAuthStore } from '@/store/auth';
import { Colors, Spacing, BorderRadius, Typography, SubscriptionTiers } from '@/constants';

export default function ProfileScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const colors = isDark ? Colors.dark : Colors.light;

  const { user, isAuthenticated } = useAuthStore();

  if (!isAuthenticated || !user) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <Ionicons name="person-circle-outline" size={80} color={colors.textTertiary} />
        <Text style={[styles.loginTitle, { color: colors.text }]}>Sign in to JoinUp</Text>
        <Text style={[styles.loginSubtitle, { color: colors.textSecondary }]}>
          Create your profile, discover events, and connect with others
        </Text>
        <TouchableOpacity
          style={[styles.loginButton, { backgroundColor: colors.primary }]}
          onPress={() => router.push('/auth/login')}
        >
          <Text style={styles.loginButtonText}>Sign In</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => router.push('/auth/register')}>
          <Text style={[styles.registerLink, { color: colors.primary }]}>
            Don't have an account? Sign Up
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  const tierInfo = SubscriptionTiers[user.subscriptionTier];

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View style={[styles.coverImage, { backgroundColor: colors.primary }]}>
          {user.coverImageUrl && (
            <Image source={{ uri: user.coverImageUrl }} style={StyleSheet.absoluteFill} />
          )}
        </View>

        <TouchableOpacity
          style={[styles.settingsButton, { backgroundColor: colors.background }]}
          onPress={() => router.push('/settings')}
        >
          <Ionicons name="settings-outline" size={22} color={colors.text} />
        </TouchableOpacity>

        <View style={styles.avatarContainer}>
          <Image
            source={{ uri: user.avatarUrl || 'https://via.placeholder.com/100' }}
            style={styles.avatar}
          />
          <TouchableOpacity
            style={[styles.editAvatarButton, { backgroundColor: colors.primary }]}
            onPress={() => router.push('/profile/edit')}
          >
            <Ionicons name="pencil" size={14} color="#fff" />
          </TouchableOpacity>
        </View>

        <Text style={[styles.name, { color: colors.text }]}>{user.name}</Text>
        <Text style={[styles.username, { color: colors.textSecondary }]}>@{user.username}</Text>

        {user.bio && (
          <Text style={[styles.bio, { color: colors.textSecondary }]}>{user.bio}</Text>
        )}

        {user.subscriptionTier !== 'FREE' && (
          <View style={[styles.subscriptionBadge, { backgroundColor: colors.primary + '20' }]}>
            <Ionicons name="star" size={14} color={colors.primary} />
            <Text style={[styles.subscriptionText, { color: colors.primary }]}>
              {tierInfo.name} Member
            </Text>
          </View>
        )}

        <View style={styles.stats}>
          <TouchableOpacity style={styles.statItem}>
            <Text style={[styles.statNumber, { color: colors.text }]}>
              {user._count?.hostedEvents || 0}
            </Text>
            <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Events</Text>
          </TouchableOpacity>
          <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
          <TouchableOpacity style={styles.statItem}>
            <Text style={[styles.statNumber, { color: colors.text }]}>
              {user._count?.followers || 0}
            </Text>
            <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Followers</Text>
          </TouchableOpacity>
          <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
          <TouchableOpacity style={styles.statItem}>
            <Text style={[styles.statNumber, { color: colors.text }]}>
              {user._count?.following || 0}
            </Text>
            <Text style={[styles.statLabel, { color: colors.textSecondary }]}>Following</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={[styles.primaryButton, { backgroundColor: colors.primary }]}
            onPress={() => router.push('/profile/edit')}
          >
            <Text style={styles.primaryButtonText}>Edit Profile</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.secondaryButton, { borderColor: colors.border }]}
            onPress={() => router.push('/profile/qr')}
          >
            <Ionicons name="qr-code" size={20} color={colors.text} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.menuSection}>
        <MenuItem icon="calendar-outline" label="My Events" onPress={() => {}} colors={colors} />
        <MenuItem icon="ticket-outline" label="My Tickets" onPress={() => {}} colors={colors} />
        <MenuItem icon="bookmark-outline" label="Saved Events" onPress={() => {}} colors={colors} />
        <MenuItem
          icon="star-outline"
          label="Upgrade Plan"
          onPress={() => router.push('/settings/subscription')}
          colors={colors}
          showBadge={user.subscriptionTier === 'FREE'}
        />
      </View>
    </ScrollView>
  );
}

interface MenuItemProps {
  icon: string;
  label: string;
  onPress: () => void;
  colors: typeof Colors.light;
  showBadge?: boolean;
}

function MenuItem({ icon, label, onPress, colors, showBadge }: MenuItemProps) {
  return (
    <TouchableOpacity
      style={[styles.menuItem, { borderBottomColor: colors.border }]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <View style={styles.menuItemLeft}>
        <Ionicons name={icon as any} size={22} color={colors.textSecondary} />
        <Text style={[styles.menuItemLabel, { color: colors.text }]}>{label}</Text>
      </View>
      <View style={styles.menuItemRight}>
        {showBadge && (
          <View style={[styles.badge, { backgroundColor: colors.primary }]}>
            <Text style={styles.badgeText}>PRO</Text>
          </View>
        )}
        <Ionicons name="chevron-forward" size={20} color={colors.textTertiary} />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { alignItems: 'center', justifyContent: 'center', padding: Spacing.xl },
  loginTitle: { fontFamily: 'Inter-Bold', fontSize: Typography.fontSize['2xl'], marginTop: Spacing.lg, textAlign: 'center' },
  loginSubtitle: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.base, marginTop: Spacing.sm, textAlign: 'center', lineHeight: 22 },
  loginButton: { paddingHorizontal: Spacing['2xl'], paddingVertical: Spacing.md, borderRadius: BorderRadius.lg, marginTop: Spacing.xl },
  loginButtonText: { color: '#fff', fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.base },
  registerLink: { fontFamily: 'Inter-Medium', fontSize: Typography.fontSize.sm, marginTop: Spacing.lg },
  header: { alignItems: 'center', paddingBottom: Spacing.xl },
  coverImage: { width: '100%', height: 120 },
  settingsButton: { position: 'absolute', top: Spacing.xl + 20, right: Spacing.base, width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  avatarContainer: { marginTop: -50, position: 'relative' },
  avatar: { width: 100, height: 100, borderRadius: 50, borderWidth: 4, borderColor: '#fff' },
  editAvatarButton: { position: 'absolute', bottom: 0, right: 0, width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: '#fff' },
  name: { fontFamily: 'Inter-Bold', fontSize: Typography.fontSize.xl, marginTop: Spacing.md },
  username: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.base, marginTop: Spacing.xs },
  bio: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.sm, marginTop: Spacing.sm, textAlign: 'center', paddingHorizontal: Spacing.xl, lineHeight: 20 },
  subscriptionBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: BorderRadius.full, marginTop: Spacing.md, gap: Spacing.xs },
  subscriptionText: { fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.sm },
  stats: { flexDirection: 'row', alignItems: 'center', marginTop: Spacing.lg, paddingHorizontal: Spacing.xl },
  statItem: { flex: 1, alignItems: 'center' },
  statNumber: { fontFamily: 'Inter-Bold', fontSize: Typography.fontSize.xl },
  statLabel: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.sm, marginTop: 2 },
  statDivider: { width: 1, height: 30 },
  actionButtons: { flexDirection: 'row', paddingHorizontal: Spacing.base, marginTop: Spacing.lg, gap: Spacing.sm },
  primaryButton: { flex: 1, paddingVertical: Spacing.md, borderRadius: BorderRadius.lg, alignItems: 'center' },
  primaryButtonText: { color: '#fff', fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.base },
  secondaryButton: { width: 48, height: 48, borderRadius: BorderRadius.lg, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  menuSection: { marginTop: Spacing.xl },
  menuItem: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: Spacing.base, paddingVertical: Spacing.md, borderBottomWidth: 1 },
  menuItemLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  menuItemLabel: { fontFamily: 'Inter-Medium', fontSize: Typography.fontSize.base },
  menuItemRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  badge: { paddingHorizontal: Spacing.sm, paddingVertical: 2, borderRadius: BorderRadius.sm },
  badgeText: { color: '#fff', fontFamily: 'Inter-Bold', fontSize: 10 },
});

// =============================================================================
// EVENT DETAIL SCREEN
// =============================================================================

import { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  useColorScheme,
  Alert,
  Share,
  Dimensions,
} from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { format } from 'date-fns';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, EventCategories, Spacing, BorderRadius, Typography } from '@/constants';
import { apiClient } from '@/lib/api';
import { useAuthStore } from '@/store/auth';
import type { Event } from '@/types';

const { width } = Dimensions.get('window');
const IMAGE_HEIGHT = 300;

export default function EventDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const queryClient = useQueryClient();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const colors = isDark ? Colors.dark : Colors.light;

  const { user, isAuthenticated } = useAuthStore();
  const [isSaved, setIsSaved] = useState(false);

  // Fetch event
  const { data: event, isLoading, error } = useQuery({
    queryKey: ['event', id],
    queryFn: () => apiClient.get<Event>(`/events/${id}`),
    enabled: !!id,
  });

  // Join event mutation
  const joinMutation = useMutation({
    mutationFn: () => apiClient.post(`/events/${id}/join`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['event', id] });
      Alert.alert('Success', "You're going to this event!");
    },
    onError: (error: any) => {
      Alert.alert('Error', error.response?.data?.error?.message || 'Failed to join event');
    },
  });

  // Leave event mutation
  const leaveMutation = useMutation({
    mutationFn: () => apiClient.delete(`/events/${id}/join`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['event', id] });
    },
  });

  const handleShare = async () => {
    if (!event) return;
    try {
      await Share.share({
        title: event.title,
        message: `Check out "${event.title}" on JoinUp!\n\nhttps://joinup.app/event/${event.id}`,
      });
    } catch (error) {
      console.error('Share error:', error);
    }
  };

  const handleJoin = () => {
    if (!isAuthenticated) {
      Alert.alert('Sign In Required', 'Please sign in to join events', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Sign In', onPress: () => router.push('/auth/login') },
      ]);
      return;
    }

    if (event?.isAttending) {
      Alert.alert('Leave Event', 'Are you sure you want to leave this event?', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Leave', style: 'destructive', onPress: () => leaveMutation.mutate() },
      ]);
    } else {
      joinMutation.mutate();
    }
  };

  if (isLoading) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.textSecondary }}>Loading...</Text>
      </View>
    );
  }

  if (error || !event) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <Ionicons name="warning-outline" size={48} color={colors.textTertiary} />
        <Text style={[styles.errorText, { color: colors.text }]}>Event not found</Text>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={[styles.errorLink, { color: colors.primary }]}>Go back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const categoryInfo = EventCategories.find((c) => c.id === event.category);
  const formattedDate = format(new Date(event.startTime), 'EEEE, MMMM d, yyyy');
  const formattedTime = `${format(new Date(event.startTime), 'h:mm a')} - ${format(new Date(event.endTime), 'h:mm a')}`;
  const isFree = !event.ticketTypes?.some((t) => t.priceCents > 0);
  const lowestPrice = event.ticketTypes?.reduce((min, t) => Math.min(min, t.priceCents), Infinity) || 0;
  const isHost = user?.id === event.hostId;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Stack.Screen options={{ headerShown: false }} />

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Hero Image */}
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: event.imageUrl || 'https://via.placeholder.com/800x400' }}
            style={styles.heroImage}
            contentFit="cover"
          />
          <LinearGradient
            colors={['transparent', 'rgba(0,0,0,0.7)']}
            style={styles.imageGradient}
          />

          {/* Back Button */}
          <TouchableOpacity
            style={[styles.backButton, { backgroundColor: colors.background }]}
            onPress={() => router.back()}
          >
            <Ionicons name="arrow-back" size={24} color={colors.text} />
          </TouchableOpacity>

          {/* Action Buttons */}
          <View style={styles.headerActions}>
            <TouchableOpacity
              style={[styles.actionButton, { backgroundColor: colors.background }]}
              onPress={() => setIsSaved(!isSaved)}
            >
              <Ionicons
                name={isSaved ? 'bookmark' : 'bookmark-outline'}
                size={22}
                color={isSaved ? colors.primary : colors.text}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionButton, { backgroundColor: colors.background }]}
              onPress={handleShare}
            >
              <Ionicons name="share-outline" size={22} color={colors.text} />
            </TouchableOpacity>
          </View>

          {/* Category Badge */}
          <View style={[styles.categoryBadge, { backgroundColor: categoryInfo?.color }]}>
            <Ionicons name={categoryInfo?.icon as any} size={14} color="#fff" />
            <Text style={styles.categoryText}>{categoryInfo?.label}</Text>
          </View>
        </View>

        {/* Content */}
        <View style={styles.content}>
          {/* Title & Host */}
          <Text style={[styles.title, { color: colors.text }]}>{event.title}</Text>

          <TouchableOpacity
            style={styles.hostRow}
            onPress={() => router.push(`/profile/${event.host.username}`)}
          >
            <Image
              source={{ uri: event.host.avatarUrl || 'https://via.placeholder.com/40' }}
              style={styles.hostAvatar}
            />
            <View style={styles.hostInfo}>
              <Text style={[styles.hostName, { color: colors.text }]}>{event.host.name}</Text>
              <Text style={[styles.hostUsername, { color: colors.textSecondary }]}>
                @{event.host.username}
              </Text>
            </View>
            {!isHost && (
              <TouchableOpacity style={[styles.followButton, { borderColor: colors.primary }]}>
                <Text style={[styles.followButtonText, { color: colors.primary }]}>Follow</Text>
              </TouchableOpacity>
            )}
          </TouchableOpacity>

          {/* Date & Time */}
          <View style={[styles.infoCard, { backgroundColor: colors.backgroundSecondary }]}>
            <View style={[styles.infoIcon, { backgroundColor: colors.primary + '20' }]}>
              <Ionicons name="calendar" size={20} color={colors.primary} />
            </View>
            <View style={styles.infoContent}>
              <Text style={[styles.infoTitle, { color: colors.text }]}>{formattedDate}</Text>
              <Text style={[styles.infoSubtitle, { color: colors.textSecondary }]}>
                {formattedTime}
              </Text>
            </View>
            <TouchableOpacity>
              <Text style={[styles.addCalendar, { color: colors.primary }]}>Add to Calendar</Text>
            </TouchableOpacity>
          </View>

          {/* Location */}
          <View style={[styles.infoCard, { backgroundColor: colors.backgroundSecondary }]}>
            <View style={[styles.infoIcon, { backgroundColor: colors.secondary + '20' }]}>
              <Ionicons
                name={event.isOnline ? 'videocam' : 'location'}
                size={20}
                color={colors.secondary}
              />
            </View>
            <View style={styles.infoContent}>
              <Text style={[styles.infoTitle, { color: colors.text }]}>
                {event.isOnline ? 'Online Event' : event.locationName}
              </Text>
              {!event.isOnline && event.locationAddress && (
                <Text style={[styles.infoSubtitle, { color: colors.textSecondary }]}>
                  {event.locationAddress}
                </Text>
              )}
            </View>
            {!event.isOnline && (
              <TouchableOpacity>
                <Text style={[styles.viewMap, { color: colors.primary }]}>View Map</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Attendees */}
          <View style={[styles.infoCard, { backgroundColor: colors.backgroundSecondary }]}>
            <View style={[styles.infoIcon, { backgroundColor: colors.success + '20' }]}>
              <Ionicons name="people" size={20} color={colors.success} />
            </View>
            <View style={styles.infoContent}>
              <Text style={[styles.infoTitle, { color: colors.text }]}>
                {event.attendeeCount} Going
              </Text>
              <Text style={[styles.infoSubtitle, { color: colors.textSecondary }]}>
                {event.capacity - event.attendeeCount} spots left
              </Text>
            </View>
            <TouchableOpacity>
              <Text style={[styles.viewAll, { color: colors.primary }]}>See All</Text>
            </TouchableOpacity>
          </View>

          {/* Description */}
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>About</Text>
            <Text style={[styles.description, { color: colors.textSecondary }]}>
              {event.description}
            </Text>
          </View>

          {/* Tags */}
          {event.tags && event.tags.length > 0 && (
            <View style={styles.tagsContainer}>
              {event.tags.map((tag) => (
                <View key={tag} style={[styles.tag, { backgroundColor: colors.backgroundSecondary }]}>
                  <Text style={[styles.tagText, { color: colors.textSecondary }]}>#{tag}</Text>
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      {/* Bottom Bar */}
      <View style={[styles.bottomBar, { backgroundColor: colors.background, borderTopColor: colors.border }]}>
        <View style={styles.priceContainer}>
          <Text style={[styles.priceLabel, { color: colors.textSecondary }]}>
            {isFree ? 'Free Event' : 'From'}
          </Text>
          {!isFree && (
            <Text style={[styles.price, { color: colors.text }]}>
              ${(lowestPrice / 100).toFixed(2)}
            </Text>
          )}
        </View>
        <TouchableOpacity
          style={[
            styles.joinButton,
            { backgroundColor: event.isAttending ? colors.backgroundSecondary : colors.primary },
          ]}
          onPress={handleJoin}
          disabled={joinMutation.isPending || leaveMutation.isPending}
        >
          <Text
            style={[
              styles.joinButtonText,
              { color: event.isAttending ? colors.text : '#fff' },
            ]}
          >
            {event.isAttending ? "You're Going ✓" : isFree ? 'Join Event' : 'Get Tickets'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  centered: { alignItems: 'center', justifyContent: 'center' },
  errorText: { fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.lg, marginTop: Spacing.md },
  errorLink: { fontFamily: 'Inter-Medium', fontSize: Typography.fontSize.base, marginTop: Spacing.sm },
  imageContainer: { position: 'relative', height: IMAGE_HEIGHT },
  heroImage: { width: '100%', height: '100%' },
  imageGradient: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 100 },
  backButton: { position: 'absolute', top: 50, left: Spacing.base, width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  headerActions: { position: 'absolute', top: 50, right: Spacing.base, flexDirection: 'row', gap: Spacing.sm },
  actionButton: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  categoryBadge: { position: 'absolute', bottom: Spacing.base, left: Spacing.base, flexDirection: 'row', alignItems: 'center', paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: BorderRadius.full, gap: Spacing.xs },
  categoryText: { color: '#fff', fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.sm },
  content: { padding: Spacing.base },
  title: { fontFamily: 'Inter-Bold', fontSize: Typography.fontSize['2xl'], marginBottom: Spacing.md },
  hostRow: { flexDirection: 'row', alignItems: 'center', marginBottom: Spacing.lg },
  hostAvatar: { width: 48, height: 48, borderRadius: 24 },
  hostInfo: { flex: 1, marginLeft: Spacing.md },
  hostName: { fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.base },
  hostUsername: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.sm },
  followButton: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: BorderRadius.full, borderWidth: 1 },
  followButtonText: { fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.sm },
  infoCard: { flexDirection: 'row', alignItems: 'center', padding: Spacing.md, borderRadius: BorderRadius.lg, marginBottom: Spacing.sm },
  infoIcon: { width: 44, height: 44, borderRadius: BorderRadius.md, alignItems: 'center', justifyContent: 'center' },
  infoContent: { flex: 1, marginLeft: Spacing.md },
  infoTitle: { fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.base },
  infoSubtitle: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.sm, marginTop: 2 },
  addCalendar: { fontFamily: 'Inter-Medium', fontSize: Typography.fontSize.sm },
  viewMap: { fontFamily: 'Inter-Medium', fontSize: Typography.fontSize.sm },
  viewAll: { fontFamily: 'Inter-Medium', fontSize: Typography.fontSize.sm },
  section: { marginTop: Spacing.lg },
  sectionTitle: { fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.lg, marginBottom: Spacing.sm },
  description: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.base, lineHeight: 24 },
  tagsContainer: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.sm, marginTop: Spacing.lg, marginBottom: Spacing['4xl'] },
  tag: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.sm, borderRadius: BorderRadius.full },
  tagText: { fontFamily: 'Inter-Medium', fontSize: Typography.fontSize.sm },
  bottomBar: { flexDirection: 'row', alignItems: 'center', padding: Spacing.base, paddingBottom: Spacing.xl, borderTopWidth: 1 },
  priceContainer: { flex: 1 },
  priceLabel: { fontFamily: 'Inter-Regular', fontSize: Typography.fontSize.sm },
  price: { fontFamily: 'Inter-Bold', fontSize: Typography.fontSize.xl },
  joinButton: { flex: 2, paddingVertical: Spacing.md, borderRadius: BorderRadius.lg, alignItems: 'center', marginLeft: Spacing.md },
  joinButtonText: { fontFamily: 'Inter-SemiBold', fontSize: Typography.fontSize.base },
});

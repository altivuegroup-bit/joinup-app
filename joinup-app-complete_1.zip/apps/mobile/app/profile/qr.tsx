// =============================================================================
// QR CODE PROFILE SCREEN
// =============================================================================

import { View, Text, StyleSheet, TouchableOpacity, useColorScheme, Share } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import QRCode from 'react-native-qrcode-svg';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, BorderRadius, Typography, APP_NAME } from '@/constants';
import { useAuthStore } from '@/store/auth';

export default function QRProfileScreen() {
  const router = useRouter();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const colors = isDark ? Colors.dark : Colors.light;

  const { user } = useAuthStore();

  if (!user) {
    return (
      <View style={[styles.container, styles.centered, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.text }}>Please sign in</Text>
      </View>
    );
  }

  const profileUrl = `https://joinup.app/profile/${user.username}`;

  const handleShare = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      await Share.share({
        title: `${user.name} on ${APP_NAME}`,
        message: `Connect with me on ${APP_NAME}!\n\n${profileUrl}`,
        url: profileUrl,
      });
    } catch (error) {
      console.error('Share error:', error);
    }
  };

  const handleScanOthers = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push('/profile/scan');
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Profile Card */}
      <View style={[styles.card, { backgroundColor: colors.card }]}>
        {/* User Info */}
        <View style={styles.userInfo}>
          <Image
            source={{ uri: user.avatarUrl || 'https://via.placeholder.com/80' }}
            style={styles.avatar}
          />
          <Text style={[styles.name, { color: colors.text }]}>{user.name}</Text>
          <Text style={[styles.username, { color: colors.textSecondary }]}>@{user.username}</Text>
        </View>

        {/* QR Code */}
        <View style={styles.qrContainer}>
          <View style={[styles.qrWrapper, { backgroundColor: '#fff' }]}>
            <QRCode
              value={profileUrl}
              size={200}
              color="#000"
              backgroundColor="#fff"
              logo={require('@/assets/images/icon.png')}
              logoSize={40}
              logoBackgroundColor="#fff"
              logoBorderRadius={8}
            />
          </View>
        </View>

        {/* Instructions */}
        <Text style={[styles.instructions, { color: colors.textSecondary }]}>
          Let others scan this code to view your profile and connect with you on all platforms
        </Text>

        {/* Social Connections Preview */}
        {user.socialConnections && user.socialConnections.length > 0 && (
          <View style={styles.socialsPreview}>
            <Text style={[styles.socialsLabel, { color: colors.textTertiary }]}>
              Connected platforms
            </Text>
            <View style={styles.socialIcons}>
              {user.socialConnections.map((social) => (
                <View
                  key={social.platform}
                  style={[styles.socialIcon, { backgroundColor: colors.backgroundSecondary }]}
                >
                  <Ionicons
                    name={getSocialIcon(social.platform)}
                    size={18}
                    color={getSocialColor(social.platform)}
                  />
                </View>
              ))}
            </View>
          </View>
        )}
      </View>

      {/* Action Buttons */}
      <View style={styles.actions}>
        <TouchableOpacity
          style={[styles.shareButton, { backgroundColor: colors.primary }]}
          onPress={handleShare}
        >
          <Ionicons name="share-outline" size={22} color="#fff" />
          <Text style={styles.shareButtonText}>Share Profile</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.scanButton, { borderColor: colors.border }]}
          onPress={handleScanOthers}
        >
          <Ionicons name="scan-outline" size={22} color={colors.text} />
          <Text style={[styles.scanButtonText, { color: colors.text }]}>Scan Others</Text>
        </TouchableOpacity>
      </View>

      {/* Tip */}
      <View style={[styles.tipContainer, { backgroundColor: colors.backgroundSecondary }]}>
        <Ionicons name="bulb-outline" size={20} color={colors.primary} />
        <Text style={[styles.tipText, { color: colors.textSecondary }]}>
          Tip: Screenshot this QR code to share anywhere!
        </Text>
      </View>
    </View>
  );
}

function getSocialIcon(platform: string): any {
  const icons: Record<string, string> = {
    INSTAGRAM: 'logo-instagram',
    TWITTER: 'logo-twitter',
    TIKTOK: 'logo-tiktok',
    LINKEDIN: 'logo-linkedin',
    YOUTUBE: 'logo-youtube',
  };
  return icons[platform] || 'link';
}

function getSocialColor(platform: string): string {
  const colors: Record<string, string> = {
    INSTAGRAM: '#E4405F',
    TWITTER: '#1DA1F2',
    TIKTOK: '#000000',
    LINKEDIN: '#0A66C2',
    YOUTUBE: '#FF0000',
  };
  return colors[platform] || '#666666';
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: Spacing.base,
  },
  centered: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  card: {
    borderRadius: BorderRadius.xl,
    padding: Spacing.xl,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  userInfo: {
    alignItems: 'center',
    marginBottom: Spacing.xl,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: Spacing.md,
  },
  name: {
    fontFamily: 'Inter-Bold',
    fontSize: Typography.fontSize.xl,
  },
  username: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.base,
    marginTop: Spacing.xs,
  },
  qrContainer: {
    padding: Spacing.md,
  },
  qrWrapper: {
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
  },
  instructions: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.sm,
    textAlign: 'center',
    marginTop: Spacing.lg,
    lineHeight: 20,
    paddingHorizontal: Spacing.md,
  },
  socialsPreview: {
    alignItems: 'center',
    marginTop: Spacing.lg,
  },
  socialsLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.xs,
    marginBottom: Spacing.sm,
  },
  socialIcons: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  socialIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actions: {
    flexDirection: 'row',
    gap: Spacing.md,
    marginTop: Spacing.xl,
  },
  shareButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.lg,
    gap: Spacing.sm,
  },
  shareButtonText: {
    color: '#fff',
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.base,
  },
  scanButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    gap: Spacing.sm,
  },
  scanButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: Typography.fontSize.base,
  },
  tipContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    marginTop: Spacing.lg,
    gap: Spacing.sm,
  },
  tipText: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: Typography.fontSize.sm,
  },
});

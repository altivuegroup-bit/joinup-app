// =============================================================================
// AUTH STORE
// =============================================================================

import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';
import { apiClient } from '@/lib/api';
import { StorageKeys } from '@/constants';
import type { User, AuthResponse, LoginRequest, RegisterRequest } from '@/types';

// =============================================================================
// TYPES
// =============================================================================

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  
  // Actions
  initialize: () => Promise<void>;
  login: (data: LoginRequest) => Promise<void>;
  register: (data: RegisterRequest) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (user: Partial<User>) => void;
  refreshUser: () => Promise<void>;
}

// =============================================================================
// STORE
// =============================================================================

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  isLoading: true,
  isAuthenticated: false,

  // ===========================================================================
  // INITIALIZE (check for existing session)
  // ===========================================================================
  initialize: async () => {
    try {
      const [accessToken, userJson] = await Promise.all([
        SecureStore.getItemAsync(StorageKeys.ACCESS_TOKEN),
        SecureStore.getItemAsync(StorageKeys.USER),
      ]);

      if (accessToken && userJson) {
        const user = JSON.parse(userJson) as User;
        set({ user, isAuthenticated: true, isLoading: false });
        
        // Refresh user data in background
        get().refreshUser().catch(console.error);
      } else {
        set({ isLoading: false });
      }
    } catch (error) {
      console.error('Failed to initialize auth:', error);
      set({ isLoading: false });
    }
  },

  // ===========================================================================
  // LOGIN
  // ===========================================================================
  login: async (data: LoginRequest) => {
    const response = await apiClient.post<AuthResponse>('/auth/login', data);
    
    await Promise.all([
      SecureStore.setItemAsync(StorageKeys.ACCESS_TOKEN, response.accessToken),
      SecureStore.setItemAsync(StorageKeys.REFRESH_TOKEN, response.refreshToken),
      SecureStore.setItemAsync(StorageKeys.USER, JSON.stringify(response.user)),
    ]);

    set({ user: response.user, isAuthenticated: true });
  },

  // ===========================================================================
  // REGISTER
  // ===========================================================================
  register: async (data: RegisterRequest) => {
    const response = await apiClient.post<AuthResponse>('/auth/register', data);
    
    await Promise.all([
      SecureStore.setItemAsync(StorageKeys.ACCESS_TOKEN, response.accessToken),
      SecureStore.setItemAsync(StorageKeys.REFRESH_TOKEN, response.refreshToken),
      SecureStore.setItemAsync(StorageKeys.USER, JSON.stringify(response.user)),
    ]);

    set({ user: response.user, isAuthenticated: true });
  },

  // ===========================================================================
  // LOGOUT
  // ===========================================================================
  logout: async () => {
    try {
      await apiClient.post('/auth/logout');
    } catch (error) {
      // Continue with local logout even if API fails
      console.error('Logout API error:', error);
    }

    await Promise.all([
      SecureStore.deleteItemAsync(StorageKeys.ACCESS_TOKEN),
      SecureStore.deleteItemAsync(StorageKeys.REFRESH_TOKEN),
      SecureStore.deleteItemAsync(StorageKeys.USER),
    ]);

    set({ user: null, isAuthenticated: false });
  },

  // ===========================================================================
  // UPDATE USER (local)
  // ===========================================================================
  updateUser: (updates: Partial<User>) => {
    const currentUser = get().user;
    if (currentUser) {
      const updatedUser = { ...currentUser, ...updates };
      set({ user: updatedUser });
      SecureStore.setItemAsync(StorageKeys.USER, JSON.stringify(updatedUser));
    }
  },

  // ===========================================================================
  // REFRESH USER (from API)
  // ===========================================================================
  refreshUser: async () => {
    try {
      const response = await apiClient.get<{ user: User }>('/auth/me');
      set({ user: response.user });
      await SecureStore.setItemAsync(StorageKeys.USER, JSON.stringify(response.user));
    } catch (error) {
      console.error('Failed to refresh user:', error);
    }
  },
}));

// =============================================================================
// APP CONSTANTS
// =============================================================================

export const APP_NAME = 'JoinUp';

// =============================================================================
// COLORS
// =============================================================================

export const Colors = {
  light: {
    // Primary
    primary: '#FF6B35',
    primaryLight: '#FF8F65',
    primaryDark: '#E55A2B',
    
    // Secondary
    secondary: '#4ECDC4',
    secondaryLight: '#7EDDD6',
    secondaryDark: '#3DBDB4',
    
    // Backgrounds
    background: '#FFFFFF',
    backgroundSecondary: '#F8F9FA',
    backgroundTertiary: '#F1F3F4',
    
    // Text
    text: '#1A1A1A',
    textSecondary: '#6B7280',
    textTertiary: '#9CA3AF',
    textInverse: '#FFFFFF',
    
    // Borders
    border: '#E5E7EB',
    borderLight: '#F3F4F6',
    
    // Status
    success: '#10B981',
    warning: '#F59E0B',
    error: '#EF4444',
    info: '#3B82F6',
    
    // Misc
    card: '#FFFFFF',
    shadow: 'rgba(0, 0, 0, 0.1)',
    overlay: 'rgba(0, 0, 0, 0.5)',
    
    // Tab bar
    tabIconDefault: '#9CA3AF',
    tabIconSelected: '#FF6B35',
  },
  dark: {
    // Primary
    primary: '#FF6B35',
    primaryLight: '#FF8F65',
    primaryDark: '#E55A2B',
    
    // Secondary
    secondary: '#4ECDC4',
    secondaryLight: '#7EDDD6',
    secondaryDark: '#3DBDB4',
    
    // Backgrounds
    background: '#0F0F0F',
    backgroundSecondary: '#1A1A1A',
    backgroundTertiary: '#262626',
    
    // Text
    text: '#FFFFFF',
    textSecondary: '#A1A1AA',
    textTertiary: '#71717A',
    textInverse: '#1A1A1A',
    
    // Borders
    border: '#27272A',
    borderLight: '#3F3F46',
    
    // Status
    success: '#10B981',
    warning: '#F59E0B',
    error: '#EF4444',
    info: '#3B82F6',
    
    // Misc
    card: '#1A1A1A',
    shadow: 'rgba(0, 0, 0, 0.3)',
    overlay: 'rgba(0, 0, 0, 0.7)',
    
    // Tab bar
    tabIconDefault: '#71717A',
    tabIconSelected: '#FF6B35',
  },
};

// =============================================================================
// TYPOGRAPHY
// =============================================================================

export const Typography = {
  fontSize: {
    xs: 12,
    sm: 14,
    base: 16,
    lg: 18,
    xl: 20,
    '2xl': 24,
    '3xl': 30,
    '4xl': 36,
  },
  fontWeight: {
    normal: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
  },
  lineHeight: {
    tight: 1.25,
    normal: 1.5,
    relaxed: 1.75,
  },
};

// =============================================================================
// SPACING
// =============================================================================

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  '2xl': 32,
  '3xl': 40,
  '4xl': 48,
};

// =============================================================================
// BORDER RADIUS
// =============================================================================

export const BorderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  '2xl': 20,
  full: 9999,
};

// =============================================================================
// SHADOWS
// =============================================================================

export const Shadows = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 5,
  },
};

// =============================================================================
// CATEGORIES
// =============================================================================

export const EventCategories = [
  { id: 'WELLNESS', label: 'Wellness', icon: 'heart', color: '#10B981' },
  { id: 'MUSIC', label: 'Music', icon: 'musical-notes', color: '#8B5CF6' },
  { id: 'TECH', label: 'Tech', icon: 'laptop', color: '#3B82F6' },
  { id: 'FOOD', label: 'Food', icon: 'restaurant', color: '#F59E0B' },
  { id: 'ART', label: 'Art', icon: 'color-palette', color: '#EC4899' },
  { id: 'SPORTS', label: 'Sports', icon: 'basketball', color: '#EF4444' },
  { id: 'SOCIAL', label: 'Social', icon: 'people', color: '#06B6D4' },
  { id: 'BUSINESS', label: 'Business', icon: 'briefcase', color: '#6366F1' },
  { id: 'EDUCATION', label: 'Education', icon: 'school', color: '#14B8A6' },
  { id: 'OTHER', label: 'Other', icon: 'ellipsis-horizontal', color: '#6B7280' },
] as const;

// =============================================================================
// SUBSCRIPTION TIERS
// =============================================================================

export const SubscriptionTiers = {
  FREE: {
    id: 'FREE',
    name: 'Free',
    price: 0,
    features: [
      'Browse unlimited events',
      'Join up to 3 events/month',
      'Basic profile',
    ],
  },
  CONNECT: {
    id: 'CONNECT',
    name: 'Connect',
    price: 299, // cents
    features: [
      'Everything in Free',
      'Unlimited event joins',
      'QR code profile',
      'Connect 3 social platforms',
      'Direct messaging',
    ],
  },
  CREATOR: {
    id: 'CREATOR',
    name: 'Creator',
    price: 699, // cents
    features: [
      'Everything in Connect',
      'Host unlimited events',
      'Sell tickets (2% fee)',
      'Unlimited social links',
      'Analytics dashboard',
      'Priority support',
    ],
  },
} as const;

// =============================================================================
// API CONFIG
// =============================================================================

export const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:3001';
export const WS_URL = process.env.EXPO_PUBLIC_WS_URL || 'ws://localhost:3001';

// =============================================================================
// STORAGE KEYS
// =============================================================================

export const StorageKeys = {
  ACCESS_TOKEN: 'joinup_access_token',
  REFRESH_TOKEN: 'joinup_refresh_token',
  USER: 'joinup_user',
  ONBOARDING_COMPLETE: 'joinup_onboarding_complete',
  THEME: 'joinup_theme',
  PUSH_TOKEN: 'joinup_push_token',
} as const;

// =============================================================================
// LIMITS
// =============================================================================

export const Limits = {
  BIO_MAX_LENGTH: 160,
  EVENT_TITLE_MAX_LENGTH: 100,
  EVENT_DESCRIPTION_MAX_LENGTH: 2000,
  MESSAGE_MAX_LENGTH: 1000,
  REVIEW_MAX_LENGTH: 500,
  IMAGE_MAX_SIZE_MB: 10,
  IMAGES_PER_EVENT: 10,
} as const;
